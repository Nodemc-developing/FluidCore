package net.momirealms.sparrow.yaml;

import net.momirealms.sparrow.yaml.exception.AutoSerializerException;
import net.momirealms.sparrow.yaml.exception.InvalidNodeException;
import net.momirealms.sparrow.yaml.exception.MissingNodeException;
import net.momirealms.sparrow.yaml.serializer.auto.annotation.Comment;
import net.momirealms.sparrow.yaml.serializer.auto.annotation.Configuration;
import net.momirealms.sparrow.yaml.serializer.auto.annotation.AfterComment;
import net.momirealms.sparrow.yaml.serializer.auto.annotation.InlineComment;
import net.momirealms.sparrow.yaml.serializer.auto.annotation.BlankLineBefore;
import net.momirealms.sparrow.yaml.serializer.auto.annotation.YamlConstructor;
import net.momirealms.sparrow.yaml.serializer.auto.annotation.YamlProperty;
import net.momirealms.sparrow.yaml.mapper.YamlMapper;
import net.momirealms.sparrow.yaml.mapper.YamlMapperFactory;
import net.momirealms.sparrow.yaml.node.SectionNode;
import net.momirealms.sparrow.yaml.route.Route;
import net.momirealms.sparrow.yaml.serializer.NodeSerializer;
import net.momirealms.sparrow.yaml.serializer.NodeSerializers;
import net.momirealms.sparrow.yaml.serializer.auto.AutoSerializerMode;
import net.momirealms.sparrow.yaml.upgrade.YamlUpgradePipeline;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotSame;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SparrowYamlAnnotationTest {

    @Configuration
    public static class TestConfig {
        @Comment("This is a host")
        private String host = "127.0.0.1";

        @Comment({"Port number", "Must be > 1024"})
        @YamlProperty("server-port")
        private int port = 8080;

        @InlineComment("List of users")
        @AfterComment("Generated users section")
        private List<String> users = List.of("admin", "guest");

        @Comment("Nested Config")
        private NestedConfig nested = new NestedConfig();

        public String getHost() { return host; }
        public void setHost(String host) { this.host = host; }
        public int getPort() { return port; }
        public void setPort(int port) { this.port = port; }
        public List<String> getUsers() { return users; }
        public void setUsers(List<String> users) { this.users = users; }
        public NestedConfig getNested() { return nested; }
        public void setNested(NestedConfig nested) { this.nested = nested; }
    }

    public static class NestedConfig {
        @Comment("Enable something")
        private boolean enabled = true;

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }
    }

    @Configuration
    public static class FormattingConfig {
        @Comment("Forces locale")
        private Locale locale = null;

        @BlankLineBefore
        @Comment("Debug")
        private NestedConfig debug = new NestedConfig();

        public Locale getLocale() { return locale; }
        public NestedConfig getDebug() { return debug; }
    }

    @Configuration(naming = Configuration.Naming.KEBAB_CASE)
    public static class NestedCommentConfig {
        @Comment("Do not modify this value")
        private String configVersion = "1";

        @BlankLineBefore
        @Comment("Synchronization settings")
        private SynchronizationSettings synchronization = new SynchronizationSettings();
    }

    // 嵌套配置类的命名风格按自身类型解析, 不继承外层
    @Configuration(naming = Configuration.Naming.SNAKE_CASE)
    public static class SynchronizationSettings {
        @Comment({
                "Number of worker threads handling per-player tasks",
                "Tasks of one player always run on the same worker in submission order"
        })
        private int workerThreads = 4;

        @BlankLineBefore
        @Comment("How long to wait for pending saves")
        private int shutdownTimeoutSeconds = 60;
    }

    @Configuration
    public static class SelfRefNodeConfig {
        @Comment("Node name")
        private String name = "root";

        @Comment("Child node")
        private SelfRefNodeConfig child = null;
    }

    @Configuration
    public static class VersionedConfig {
        @YamlProperty("config-version")
        private String version = "2";

        private String value = "default";

        private String added = "created";

        public String getVersion() { return version; }
        public String getValue() { return value; }
        public String getAdded() { return added; }
    }

    @Configuration
    public static class VersionedMapConfig {
        @YamlProperty("config-version")
        private String version = "2";

        private Map<String, Integer> rewards = Map.of("default", 10);

        public String getVersion() { return version; }

        public Map<String, Integer> getRewards() { return rewards; }

    }

    public static class DynamicNestedConfig {

        private Map<ConfigKey, String> overrides = Map.of(new ConfigKey("minecraft", "stone"), "block");

        public Map<ConfigKey, String> overrides() { return this.overrides; }

    }

    @Configuration
    public static class VersionedNestedMapConfig {

        @YamlProperty("config-version")
        private String version = "2";

        private DynamicNestedConfig nested = new DynamicNestedConfig();

        public DynamicNestedConfig nested() { return this.nested; }

    }

    public static class InheritedBaseConfig {
        @Comment("Base host")
        protected String host = "127.0.0.1";

        @BlankLineBefore
        @Comment("Base locale")
        protected Locale locale = Locale.US;

        public String getHost() { return host; }
        public Locale getLocale() { return locale; }
    }

    @Configuration
    public static class InheritedConfig extends InheritedBaseConfig {
        @Comment("Child port")
        private int port = 25565;

        public int getPort() { return port; }
    }

    @Configuration
    public static class ImmutableConfig {
        @YamlProperty("server-name")
        @Comment("Immutable name")
        private final String name;

        private final int limit;

        @YamlConstructor
        public ImmutableConfig(
                @YamlProperty("server-name") String name,
                @YamlProperty("limit") int limit
        ) {
            this.name = name;
            this.limit = limit;
        }

        public String getName() { return name; }
        public int getLimit() { return limit; }
    }

    @Configuration
    public static class RequiredConstructorConfig {
        private final int port;

        @YamlConstructor
        public RequiredConstructorConfig(@YamlProperty("server-port") int port) {
            this.port = port;
        }

        public int getPort() { return port; }
    }

    @Configuration
    public record RecordConfig(
            @Comment("Record host") String host,
            @InlineComment("Record port")
            @AfterComment("Generated record port") int port
    ) {
    }

    public record ConfigKey(String namespace, String value) {

        static ConfigKey parse(String input) {
            String[] parts = input.split(":", 2);
            return parts.length == 2 ? new ConfigKey(parts[0], parts[1]) : null;
        }

        String asString() {
            return this.namespace + ":" + this.value;
        }
    }

    @Configuration
    public static class KeyedConfig {
        private Map<ConfigKey, String> values = Map.of();

        public Map<ConfigKey, String> values() {
            return this.values;
        }
    }

    public static class NamingBaseConfig {
        protected int maxPlayerCount = 20;
    }

    public static class PlainNestedConfig {
        private boolean keepInventory = true;
    }

    @Configuration(naming = Configuration.Naming.SNAKE_CASE)
    public static class SnakeNamingConfig extends NamingBaseConfig {
        @Comment("Online mode")
        private boolean onlineMode = true;
        private String httpServerURL = "localhost";
        @YamlProperty("keep-inventory")
        private boolean keepInventory = false;
        private Map<ConfigKey, String> customValues = Map.of();
        private PlainNestedConfig nestedSettings = new PlainNestedConfig();
    }

    @Configuration(naming = Configuration.Naming.KEBAB_CASE)
    public record KebabNamingRecord(
            boolean keepInventory,
            @YamlProperty("online_mode") boolean onlineMode
    ) {
    }

    @Configuration
    public static class AsIsNamingConfig {
        private boolean onlineMode = true;
    }

    @Configuration(naming = Configuration.Naming.SNAKE_CASE)
    public static class NamingCollisionConfig {
        private String onlineMode;
        private String online_mode;
    }

    public enum CompressionStrategy {
        ZSTD,
        DEFLATE
    }

    @Configuration
    public static class EnumFallbackConfig {
        private CompressionStrategy compression = CompressionStrategy.ZSTD;
        private String marker = "default";
    }

    @Configuration
    public static class EnumWithoutDefaultConfig {
        private CompressionStrategy compression;
    }

    public static class GenericEnumBase<T extends Enum<T>> {
        protected T compression;
    }

    @Configuration
    public static class GenericEnumFallbackConfig extends GenericEnumBase<CompressionStrategy> {
        public GenericEnumFallbackConfig() {
            this.compression = CompressionStrategy.ZSTD;
        }
    }

    @Configuration
    public static class EnumListConfig {
        private List<CompressionStrategy> compression = List.of(CompressionStrategy.ZSTD);
    }

    @Configuration
    public record EnumRecordConfig(CompressionStrategy compression) {
    }

    @Configuration
    public static class UnsafeEnumConfig {
        private CompressionStrategy compression = CompressionStrategy.ZSTD;

        public UnsafeEnumConfig(String ignored) {
        }

        public UnsafeEnumConfig(int ignored) {
        }
    }

    @Test
    void testLoadObjectAndInjectComments() throws IOException {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlMapperFactory factory = YamlMapperFactory.builder().sparrowYaml(sparrowYaml).build();
        YamlMapper<TestConfig> mapper = factory.create(TestConfig.class, TestConfig::new);

        TestConfig config = new TestConfig();
        config.setHost("192.168.1.1");
        
        Path tempFile = Files.createTempFile("test_config", ".yml");
        mapper.save(tempFile, config);
        
        String yamlString = Files.readString(tempFile);
        System.out.println(yamlString);

        assertTrue(yamlString.contains("# This is a host"));
        assertTrue(yamlString.contains("host: 192.168.1.1"));
        
        assertTrue(yamlString.contains("# Port number"));
        assertTrue(yamlString.contains("# Must be > 1024"));
        assertTrue(yamlString.contains("server-port: 8080"));
        
        assertTrue(yamlString.contains("# Nested Config"));
        assertTrue(yamlString.contains("nested:"));
        assertTrue(yamlString.contains("# Enable something"));
        assertTrue(yamlString.contains("enabled: true"));
        
        assertTrue(yamlString.contains("users:"));
        assertTrue(yamlString.contains("# Generated users section"));
    }

    @Test
    void should_RoundTripMapWithSerializedKey_When_UsingMapper(@TempDir Path tempDir) throws Exception {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        sparrowYaml.serializers().register(ConfigKey.class, NodeSerializers.scalar(ConfigKey.class, ConfigKey::parse, ConfigKey::asString));
        YamlMapper<KeyedConfig> mapper = sparrowYaml.mapper(KeyedConfig.class, KeyedConfig::new);
        Path path = tempDir.resolve("keyed-config.yml");
        Files.writeString(path, """
                values:
                  "minecraft:stone": block
                """);

        KeyedConfig config = mapper.loadValue(path);
        assertEquals("block", config.values().get(new ConfigKey("minecraft", "stone")));

        mapper.save(path, config);
        KeyedConfig reloaded = mapper.loadValue(path);
        assertEquals(config.values(), reloaded.values());
    }

    @Test
    void should_KeepInitializedEnumField_When_ConfigValueIsUnknown(@TempDir Path tempDir) throws Exception {
        assertAll(
                () -> assertEnumFallbackContract(AutoSerializerMode.ADAPTIVE, tempDir),
                () -> assertEnumFallbackContract(AutoSerializerMode.ASM, tempDir),
                () -> assertEnumFallbackContract(AutoSerializerMode.REFLECTION, tempDir)
        );
    }

    @Test
    void should_RoundTripConfigurationNamingWithoutChangingMapKeysOrNestedTypes(@TempDir Path tempDir) throws Exception {
        AutoSerializerMode[] modes = {AutoSerializerMode.REFLECTION, AutoSerializerMode.ASM};
        for (int i = 0; i < modes.length; i++) {
            SparrowYaml sparrowYaml = SparrowYaml.builder().setAutoSerializerMode(modes[i]).build();
            sparrowYaml.serializers().register(ConfigKey.class, NodeSerializers.scalar(ConfigKey.class, ConfigKey::parse, ConfigKey::asString));
            YamlMapperFactory factory = YamlMapperFactory.builder().sparrowYaml(sparrowYaml).build();
            YamlMapper<SnakeNamingConfig> mapper = factory.create(SnakeNamingConfig.class, SnakeNamingConfig::new);
            Path path = tempDir.resolve("snake-naming-" + modes[i].name().toLowerCase(Locale.ROOT) + ".yml");
            Files.writeString(path, """
                    max_player_count: 64
                    online_mode: false
                    http_server_url: example.org
                    keep-inventory: true
                    custom_values:
                      "minecraft:stone": block
                    nested_settings:
                      keepInventory: false
                    """);

            SnakeNamingConfig config = mapper.load(path).value();

            assertEquals(64, config.maxPlayerCount);
            assertFalse(config.onlineMode);
            assertEquals("example.org", config.httpServerURL);
            assertTrue(config.keepInventory);
            assertEquals("block", config.customValues.get(new ConfigKey("minecraft", "stone")));
            assertFalse(config.nestedSettings.keepInventory);

            mapper.save(path, config);
            String saved = Files.readString(path).replace("\r\n", "\n");

            assertTrue(saved.contains("max_player_count: 64"), saved);
            assertTrue(saved.contains("# Online mode\nonline_mode: false"), saved);
            assertTrue(saved.contains("http_server_url: example.org"), saved);
            assertTrue(saved.contains("keep-inventory: true"), saved);
            assertTrue(saved.contains("custom_values:"), saved);
            assertTrue(saved.contains("minecraft:stone"), saved);
            assertFalse(saved.contains("minecraft_stone"), saved);
            assertTrue(saved.contains("nested_settings:\n  keepInventory: false"), saved);
            assertFalse(saved.contains("nested_settings:\n  keep_inventory: false"), saved);

            SnakeNamingConfig reloaded = mapper.load(path).value();
            assertEquals(config.maxPlayerCount, reloaded.maxPlayerCount);
            assertEquals(config.onlineMode, reloaded.onlineMode);
            assertEquals(config.httpServerURL, reloaded.httpServerURL);
            assertEquals(config.keepInventory, reloaded.keepInventory);
            assertEquals(config.customValues, reloaded.customValues);
            assertEquals(config.nestedSettings.keepInventory, reloaded.nestedSettings.keepInventory);
        }
    }

    @Test
    void should_RoundTripRecordNamingAndExplicitYamlProperty() throws Exception {
        AutoSerializerMode[] modes = {AutoSerializerMode.REFLECTION, AutoSerializerMode.ASM};
        for (int i = 0; i < modes.length; i++) {
            SparrowYaml sparrowYaml = SparrowYaml.builder().setAutoSerializerMode(modes[i]).build();
            NodeSerializer<KebabNamingRecord> serializer = sparrowYaml.serializers().register(KebabNamingRecord.class);
            YamlDocument document = sparrowYaml.load("""
                    keep-inventory: false
                    online_mode: true
                    """);

            KebabNamingRecord config = serializer.deserialize(document);
            Object serialized = serializer.serialize(config);

            assertEquals(new KebabNamingRecord(false, true), config);
            assertTrue(serialized instanceof Map<?, ?>);
            Map<?, ?> values = (Map<?, ?>) serialized;
            assertEquals(false, values.get("keep-inventory"));
            assertEquals(true, values.get("online_mode"));
            assertFalse(values.containsKey("keepInventory"));
            assertFalse(values.containsKey("online-mode"));
        }
    }

    @Test
    void should_KeepAsIsDefaultAndRejectConvertedFieldCollisions() throws Exception {
        AutoSerializerMode[] modes = {AutoSerializerMode.REFLECTION, AutoSerializerMode.ASM};
        for (int i = 0; i < modes.length; i++) {
            SparrowYaml sparrowYaml = SparrowYaml.builder().setAutoSerializerMode(modes[i]).build();
            NodeSerializer<AsIsNamingConfig> serializer = sparrowYaml.serializers().register(AsIsNamingConfig.class);
            YamlDocument document = sparrowYaml.load("onlineMode: false");

            AsIsNamingConfig config = serializer.deserialize(document);
            Object serialized = serializer.serialize(config);

            assertFalse(config.onlineMode);
            assertTrue(serialized instanceof Map<?, ?>);
            Map<?, ?> values = (Map<?, ?>) serialized;
            assertEquals(false, values.get("onlineMode"));
            assertFalse(values.containsKey("online_mode"));

            AutoSerializerException exception = assertThrows(AutoSerializerException.class, () -> sparrowYaml.serializers().register(NamingCollisionConfig.class));
            assertTrue(exception.getMessage().contains("Duplicate YAML field 'online_mode'"), exception.getMessage());
        }
    }

    @Test
    void should_KeepLastValue_When_MapKeysCollide() throws Exception {
        NodeSerializer<String> keySerializer = NodeSerializers.STRING.xmap(String.class, value -> value.toLowerCase(Locale.ROOT), value -> value.toLowerCase(Locale.ROOT));
        NodeSerializer<Map<String, String>> serializer = NodeSerializers.STRING.mapOf(keySerializer);
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlDocument document = sparrowYaml.load("""
                values:
                  FIRST: one
                  first: two
                """);

        assertEquals(Map.of("first", "two"), document.get(serializer, Route.from("values")));

        Map<String, String> values = new LinkedHashMap<>();
        values.put("FIRST", "one");
        values.put("first", "two");
        assertEquals(Map.of("first", "two"), serializer.serialize(values));
    }

    @Test
    void should_SaveNewTestConfigIntoResourcesDirectory() throws Exception {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlMapperFactory factory = YamlMapperFactory.builder().sparrowYaml(sparrowYaml).build();
        YamlMapper<TestConfig> mapper = factory.create(TestConfig.class, TestConfig::new);

        withMissingResourcePath("generated-test-config.yml", configPath -> {
            TestConfig config = new TestConfig();
            config.setHost("resources-host");

            mapper.save(configPath, config);

            assertTrue(Files.exists(configPath));
            String saved = Files.readString(configPath).replace("\r\n", "\n");
            assertTrue(saved.contains("# This is a host\nhost: resources-host"), saved);
            assertTrue(saved.contains("# Port number\n# Must be > 1024\nserver-port: 8080"), saved);
            assertTrue(saved.contains("users:"), saved);
            assertTrue(saved.contains("# Nested Config\nnested:"), saved);
        });
    }

    @Test
    void should_ThrowInvalidNodeException_When_ResourceTestConfigContainsWrongType() throws Exception {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlMapperFactory factory = YamlMapperFactory.builder().sparrowYaml(sparrowYaml).build();
        YamlMapper<TestConfig> mapper = factory.create(TestConfig.class, TestConfig::new);

        withResourceFile("invalid-test-config.yml", """
                host: "resource"
                server-port:
                  nested: true
                users:
                  - "admin"
                """, configPath -> {
            InvalidNodeException failure = assertThrows(
                    InvalidNodeException.class,
                    () -> mapper.load(configPath)
            );

            assertEquals(Route.from("server-port"), failure.path());
            assertEquals(SectionNode.class, failure.actualType());
            assertEquals(Integer.class, failure.targetType());
            assertEquals("Invalid YAML value at path \"server-port\": actual Map, expected Integer", failure.getMessage());
        });
    }

    @Test
    void should_ThrowMissingNodeException_When_ResourceConstructorConfigMissesRequiredValue() throws Exception {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlMapperFactory factory = YamlMapperFactory.builder().sparrowYaml(sparrowYaml).build();
        YamlMapper<RequiredConstructorConfig> mapper = factory.create(
                RequiredConstructorConfig.class,
                () -> new RequiredConstructorConfig(8080)
        );

        withResourceFile("missing-required-constructor-config.yml", """
                unused: true
                """, configPath -> {
            MissingNodeException failure = assertThrows(
                    MissingNodeException.class,
                    () -> mapper.load(configPath)
            );

            assertEquals("server-port", failure.key());
            assertEquals(Route.from("server-port"), failure.path());
            assertEquals(Integer.class, failure.targetType());
            assertEquals("Missing YAML value 'server-port' at path \"server-port\", expected Integer", failure.getMessage());
        });
    }

    @Test
    void should_PreserveLocalComments_When_ResourceTestConfigIsSavedAgain() throws Exception {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlMapperFactory factory = YamlMapperFactory.builder().sparrowYaml(sparrowYaml).build();
        YamlMapper<TestConfig> mapper = factory.create(TestConfig.class, TestConfig::new);

        withResourceFile("commented-test-config.yml", """
                # Local host comment
                host: "resource"
                # Local port comment
                server-port: 9090
                # Local users comment
                users:
                  - "local"
                nested:
                  # Local nested enabled comment
                  enabled: false
                """, configPath -> {
            YamlMapper.Result<TestConfig> loaded = mapper.load(configPath);

            loaded.value().host = "new resource";
            mapper.save(configPath, loaded.document(), loaded.value());

            String saved = Files.readString(configPath).replace("\r\n", "\n");
            assertTrue(saved.contains("# Local host comment\nhost: new resource"), saved);
            assertTrue(saved.contains("# Local port comment\nserver-port: 9090"), saved);
            assertTrue(saved.contains("# Local users comment\nusers:"), saved);
            assertTrue(saved.contains("# Local nested enabled comment\n  enabled: false"), saved);
        });
    }

    @Test
    void should_PreserveLocalCommentsOnUnchangedNodes_When_ResourceConfigIsUpgraded() throws Exception {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlMapperFactory factory = YamlMapperFactory.builder()
                .sparrowYaml(sparrowYaml)
                .upgradePipeline(YamlUpgradePipeline.builder().build())
                .build();
        YamlMapper<VersionedConfig> mapper = factory.create(VersionedConfig.class, VersionedConfig::new);

        withResourceFile("commented-versioned-config.yml", """
                config-version: 1
                # Local value comment
                value: local
                # Local legacy comment
                legacy: old
                """, configPath -> {
            VersionedConfig config = mapper.load(configPath).value();
            String saved = Files.readString(configPath).replace("\r\n", "\n");

            assertEquals("2", config.getVersion());
            assertEquals("local", config.getValue());
            assertEquals("created", config.getAdded());
            assertTrue(saved.contains("# Local value comment\nvalue: local"), saved);
            assertTrue(saved.contains("added: created"), saved);
            assertFalse(saved.contains("legacy:"), saved);
        });
    }

    @Test
    void testDeserialize() throws IOException {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlMapperFactory factory = YamlMapperFactory.builder().sparrowYaml(sparrowYaml).build();
        YamlMapper<TestConfig> mapper = factory.create(TestConfig.class, TestConfig::new);

        String yamlContent = """
                host: "localhost"
                server-port: 9090
                users:
                  - "test1"
                  - "test2"
                """;
        
        Path tempFile = Files.createTempFile("test_deserialize", ".yml");
        Files.writeString(tempFile, yamlContent);
        
        YamlMapper.Result<TestConfig> config = mapper.load(tempFile);
        
        assertNotNull(config);
        assertEquals("localhost", config.value().getHost());
        assertEquals(9090, config.value().getPort());
        assertEquals(List.of("test1", "test2"), config.value().getUsers());
    }

    @Test
    void should_WriteEmptyScalarAndBlankLine_When_UsingFormattingAnnotations() throws IOException {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlMapperFactory factory = YamlMapperFactory.builder().sparrowYaml(sparrowYaml).build();
        YamlMapper<FormattingConfig> mapper = factory.create(FormattingConfig.class, FormattingConfig::new);

        Path tempFile = Files.createTempFile("formatting_config", ".yml");
        mapper.save(tempFile, new FormattingConfig());

        String yamlString = Files.readString(tempFile).replace("\r\n", "\n");

        assertFalse(yamlString.contains("locale:"));
        assertTrue(yamlString.contains("# Debug\ndebug:"));

        YamlMapper.Result<FormattingConfig> loaded = mapper.load(tempFile);
        assertNotNull(loaded);
        assertNull(loaded.value().getLocale());
    }

    @Test
    void should_ApplyParentFieldComments_When_SavingInheritedConfig() throws IOException {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlMapperFactory factory = YamlMapperFactory.builder().sparrowYaml(sparrowYaml).build();
        YamlMapper<InheritedConfig> mapper = factory.create(InheritedConfig.class, InheritedConfig::new);

        Path tempFile = Files.createTempFile("inherited_config", ".yml");
        mapper.save(tempFile, new InheritedConfig());

        String yamlString = Files.readString(tempFile).replace("\r\n", "\n");

        assertTrue(yamlString.contains("# Base host\nhost: 127.0.0.1"));
        assertTrue(yamlString.contains("\n\n# Base locale\nlocale: en_US"));
        assertTrue(yamlString.contains("# Child port\nport: 25565"));
        assertTrue(yamlString.indexOf("host:") < yamlString.indexOf("port:"), "父类字段应排在子类字段之前");

        Files.writeString(tempFile, """
                host: "0.0.0.0"
                locale: zh_CN
                port: 24454
                """);

        InheritedConfig loaded = mapper.load(tempFile).value();
        assertEquals("0.0.0.0", loaded.getHost());
        assertEquals(new Locale("zh", "CN"), loaded.getLocale());
        assertEquals(24454, loaded.getPort());
    }

    @Test
    void should_AlwaysReturnNewResult_When_LoadIsCalled() throws IOException {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlMapperFactory factory = YamlMapperFactory.builder().sparrowYaml(sparrowYaml).build();
        YamlMapper<TestConfig> mapper = factory.create(TestConfig.class, TestConfig::new);

        Path tempFile = Files.createTempFile("no_cache_config", ".yml");
        Files.writeString(tempFile, """
                host: "fresh"
                server-port: 9090
                users:
                  - "test"
                """);

        YamlMapper.Result<TestConfig> first = mapper.load(tempFile);
        YamlMapper.Result<TestConfig> second = mapper.load(tempFile);

        assertNotSame(first, second, "每次 load 都应返回新的 Result 对象（无缓存）");
        assertNotSame(first.value(), second.value(), "每次 load 都应返回新的配置实例");
        assertEquals("fresh", first.value().getHost());
        assertEquals("fresh", second.value().getHost());
    }

    @Test
    void should_LoadUpdatedContent_When_FileIsModified() throws IOException {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlMapperFactory factory = YamlMapperFactory.builder().sparrowYaml(sparrowYaml).build();
        YamlMapper<TestConfig> mapper = factory.create(TestConfig.class, TestConfig::new);

        Path tempFile = Files.createTempFile("changed_config", ".yml");
        Files.writeString(tempFile, """
                host: "before"
                server-port: 9090
                """);

        TestConfig first = mapper.loadValue(tempFile);
        Files.writeString(tempFile, """
                host: "after-with-different-size"
                server-port: 9091
                users:
                  - "changed"
                """);

        TestConfig second = mapper.loadValue(tempFile);

        assertNotSame(first, second, "文件修改后 load 应返回新的配置对象");
        assertEquals("after-with-different-size", second.getHost());
        assertEquals(9091, second.getPort());
        assertEquals(List.of("changed"), second.getUsers());
    }

    @Test
    void should_ReturnSuppliedDefaultInstance_When_LoadValueCreatesMissingFile(@TempDir Path tempDir) throws IOException {
        SparrowYaml sparrowYaml = SparrowYaml.create();
        TestConfig supplied = new TestConfig();
        supplied.setHost("supplied");
        AtomicInteger supplierCalls = new AtomicInteger();
        YamlMapper<TestConfig> mapper = sparrowYaml.mapper(TestConfig.class, () -> {
            supplierCalls.incrementAndGet();
            return supplied;
        });

        TestConfig loaded = mapper.loadValue(tempDir.resolve("nested").resolve("config.yml"));

        assertSame(supplied, loaded);
        assertEquals(1, supplierCalls.get());
    }

    @Test
    void should_NotCreateDefaultInstance_When_LoadValueReadsExistingFileWithoutUpgrade() throws IOException {
        SparrowYaml sparrowYaml = SparrowYaml.create();
        AtomicInteger supplierCalls = new AtomicInteger();
        YamlMapper<TestConfig> mapper = sparrowYaml.mapper(TestConfig.class, () -> {
            supplierCalls.incrementAndGet();
            return new TestConfig();
        });
        Path configPath = Files.createTempFile("mapper_existing_without_upgrade", ".yml");
        Files.writeString(configPath, "host: local\nserver-port: 25565\n");

        TestConfig loaded = mapper.loadValue(configPath);

        assertEquals("local", loaded.getHost());
        assertEquals(0, supplierCalls.get());
    }

    @Test
    void should_ReturnBothDocumentAndInstance_When_LoadIsCalled() throws IOException {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlMapperFactory factory = YamlMapperFactory.builder().sparrowYaml(sparrowYaml).build();
        YamlMapper<TestConfig> mapper = factory.create(TestConfig.class, TestConfig::new);

        Path tempFile = Files.createTempFile("result_config", ".yml");
        Files.writeString(tempFile, """
                host: "with-doc"
                server-port: 9092
                """);

        YamlMapper.Result<TestConfig> result = mapper.load(tempFile);

        assertNotNull(result);
        assertNotNull(result.document(), "Result 应包含 YamlDocument");
        assertNotNull(result.value(), "Result 应包含配置实例");
        assertEquals("with-doc", result.value().getHost());
        assertEquals(9092, result.value().getPort());
    }

    @Test
    void should_CreateMissingConfig_When_MapperLoadUsesSharedUpgradeFlow() throws IOException {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlMapperFactory factory = YamlMapperFactory.builder().sparrowYaml(sparrowYaml).build();
        YamlMapper<VersionedConfig> mapper = factory.create(VersionedConfig.class, VersionedConfig::new);

        Path tempDir = Files.createTempDirectory("mapper_missing_config");
        Path configPath = tempDir.resolve("nested").resolve("config.yml");

        VersionedConfig config = mapper.load(configPath).value();

        assertTrue(Files.exists(configPath));
        assertEquals("2", config.getVersion());
        assertEquals("default", config.getValue());
        assertEquals("created", config.getAdded());
    }

    @Test
    void should_UpgradeExistingConfig_When_MapperHasUpgradePipeline() throws IOException {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlMapperFactory factory = YamlMapperFactory.builder()
                .sparrowYaml(sparrowYaml)
                .upgradePipeline(YamlUpgradePipeline.builder().build())
                .build();
        YamlMapper<VersionedConfig> mapper = factory.create(VersionedConfig.class, VersionedConfig::new);

        Path configPath = Files.createTempFile("mapper_upgrade_config", ".yml");
        Files.writeString(configPath, """
                config-version: 1
                value: local
                legacy: old
                """);

        VersionedConfig config = mapper.load(configPath).value();
        YamlDocument savedDocument = sparrowYaml.load(configPath);

        assertEquals("2", config.getVersion());
        assertEquals("local", config.getValue());
        assertEquals("created", config.getAdded());
        assertEquals("2", savedDocument.getNodeOrNull(Route.from("config-version")).value().toString());
        assertEquals("local", savedDocument.getNodeOrNull(Route.from("value")).value());
        assertEquals("created", savedDocument.getNodeOrNull(Route.from("added")).value());
        assertNull(savedDocument.getNodeOrNull(Route.from("legacy")));
    }

    @Test
    void should_PreserveLocalMapEntries_When_ConfigIsUpgraded(@TempDir Path tempDir) throws IOException {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlMapperFactory factory = YamlMapperFactory.builder()
                .sparrowYaml(sparrowYaml)
                .upgradePipeline(YamlUpgradePipeline.builder().build())
                .build();
        YamlMapper<VersionedMapConfig> mapper = factory.create(VersionedMapConfig.class, VersionedMapConfig::new);

        Path configPath = tempDir.resolve("versioned-map-config.yml");
        Files.writeString(configPath, """
                config-version: 1
                rewards:
                  default: 10
                  vip: 100
                  mvp: 500
                """);

        VersionedMapConfig config = mapper.load(configPath).value();
        String saved = Files.readString(configPath).replace("\r\n", "\n");

        assertEquals("2", config.getVersion());
        assertEquals(Map.of("default", 10, "vip", 100, "mvp", 500), config.getRewards(), "升级后应保留本地 Map 中用户自定义的条目");
        assertTrue(saved.contains("vip: 100"), saved);
        assertTrue(saved.contains("mvp: 500"), saved);
    }

    @Test
    void should_AddMissingMapFieldWithDefaults_When_ConfigIsUpgraded(@TempDir Path tempDir) throws IOException {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlMapperFactory factory = YamlMapperFactory.builder()
                .sparrowYaml(sparrowYaml)
                .upgradePipeline(YamlUpgradePipeline.builder().build())
                .build();
        YamlMapper<VersionedMapConfig> mapper = factory.create(VersionedMapConfig.class, VersionedMapConfig::new);

        Path configPath = tempDir.resolve("versioned-map-config-missing.yml");
        Files.writeString(configPath, """
                config-version: 1
                """);

        VersionedMapConfig config = mapper.load(configPath).value();
        String saved = Files.readString(configPath).replace("\r\n", "\n");

        assertEquals("2", config.getVersion());
        assertEquals(Map.of("default", 10), config.getRewards(), "本地缺失 Map 字段时, 升级应补齐模板默认条目");
        assertTrue(saved.contains("rewards:"), saved);
        assertTrue(saved.contains("default: 10"), saved);
    }

    @Test
    void should_PreserveNestedCustomKeyMapEntries_When_ConfigIsUpgraded(@TempDir Path tempDir) throws IOException {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        sparrowYaml.serializers().register(ConfigKey.class, NodeSerializers.scalar(ConfigKey.class, ConfigKey::parse, ConfigKey::asString));
        YamlMapperFactory factory = YamlMapperFactory.builder()
                .sparrowYaml(sparrowYaml)
                .upgradePipeline(YamlUpgradePipeline.builder().build())
                .build();
        YamlMapper<VersionedNestedMapConfig> mapper = factory.create(VersionedNestedMapConfig.class, VersionedNestedMapConfig::new);

        Path configPath = tempDir.resolve("versioned-nested-map-config.yml");
        Files.writeString(configPath, """
                config-version: 1
                nested:
                  overrides:
                    "minecraft:dirt": ground
                    "custom:gem": treasure
                """);

        VersionedNestedMapConfig config = mapper.load(configPath).value();
        String saved = Files.readString(configPath).replace("\r\n", "\n");

        assertEquals(Map.of(new ConfigKey("minecraft", "dirt"), "ground", new ConfigKey("custom", "gem"), "treasure"), config.nested().overrides(), "升级后应保留嵌套 Map 中用户自定义的条目, 且不回填被用户删除的默认条目");
        assertTrue(saved.contains("minecraft:dirt"), saved);
        assertTrue(saved.contains("custom:gem"), saved);
        assertFalse(saved.contains("minecraft:stone"), saved);
    }

    @Test
    void should_CreateBackup_When_MapperBackupOnUpgradeIsEnabled() throws IOException {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        AtomicInteger resolverCalls = new AtomicInteger();
        YamlMapperFactory factory = YamlMapperFactory.builder()
                .sparrowYaml(sparrowYaml)
                .upgradePipeline(YamlUpgradePipeline.builder().build())
                .backupPathResolver(path -> {
                    resolverCalls.incrementAndGet();
                    return path.resolveSibling(path.getFileName() + ".bak");
                })
                .backupOnUpgrade(true)
                .build();
        YamlMapper<VersionedConfig> mapper = factory.create(VersionedConfig.class, VersionedConfig::new);

        Path configPath = Files.createTempFile("mapper_backup_config", ".yml");
        Path backupPath = configPath.resolveSibling(configPath.getFileName() + ".bak");
        Files.writeString(configPath, """
                config-version: 1
                value: local
                legacy: old
                """);

        VersionedConfig config = mapper.load(configPath).value();
        String backup = Files.readString(backupPath);
        YamlDocument savedDocument = sparrowYaml.load(configPath);

        assertEquals("2", config.getVersion());
        assertTrue(Files.exists(backupPath));
        assertTrue(backup.contains("config-version: 1"));
        assertTrue(backup.contains("legacy: old"));
        assertEquals(1, resolverCalls.get());
        assertEquals("2", savedDocument.getNodeOrNull(Route.from("config-version")).value().toString());
        assertNull(savedDocument.getNodeOrNull(Route.from("legacy")));
    }

    @Test
    void should_NotCreateBackup_When_MapperBackupOnUpgradeIsEnabledButVersionIsCurrent() throws IOException {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        AtomicInteger resolverCalls = new AtomicInteger();
        YamlMapperFactory factory = YamlMapperFactory.builder()
                .sparrowYaml(sparrowYaml)
                .upgradePipeline(YamlUpgradePipeline.builder().build())
                .backupPathResolver(path -> {
                    resolverCalls.incrementAndGet();
                    return path.resolveSibling(path.getFileName() + ".bak");
                })
                .backupOnUpgrade(true)
                .build();
        YamlMapper<VersionedConfig> mapper = factory.create(VersionedConfig.class, VersionedConfig::new);

        Path configPath = Files.createTempFile("mapper_current_backup_config", ".yml");
        Path backupPath = configPath.resolveSibling(configPath.getFileName() + ".bak");
        Files.writeString(configPath, """
                config-version: 2
                value: local
                legacy: keep
                """);

        VersionedConfig config = mapper.load(configPath).value();

        assertEquals("2", config.getVersion());
        assertEquals(0, resolverCalls.get());
        assertFalse(Files.exists(backupPath));
        assertTrue(Files.readString(configPath).contains("legacy: keep"));
    }

    @Test
    void should_NotRewriteSameVersionConfig_When_MapperHasUpgradePipeline() throws IOException {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlMapperFactory factory = YamlMapperFactory.builder()
                .sparrowYaml(sparrowYaml)
                .upgradePipeline(YamlUpgradePipeline.builder().build())
                .build();
        YamlMapper<VersionedConfig> mapper = factory.create(VersionedConfig.class, VersionedConfig::new);

        Path configPath = Files.createTempFile("mapper_same_version_config", ".yml");
        Files.writeString(configPath, """
                config-version: 2
                value: local
                legacy: keep
                """);

        VersionedConfig config = mapper.load(configPath).value();
        String saved = Files.readString(configPath);

        assertEquals("2", config.getVersion());
        assertEquals("local", config.getValue());
        assertEquals("created", config.getAdded());
        assertTrue(saved.contains("legacy: keep"));
        assertFalse(saved.contains("added:"));
    }

    @Test
    void should_CreateMissingImmutableConfig_When_DefaultSupplierIsProvided() throws IOException {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlMapperFactory factory = YamlMapperFactory.builder().sparrowYaml(sparrowYaml).build();
        YamlMapper<ImmutableConfig> mapper = factory.create(
                ImmutableConfig.class,
                () -> new ImmutableConfig("supplier-default", 32)
        );

        Path tempFile = Files.createTempFile("immutable_default_config", ".yml");
        Files.delete(tempFile);

        ImmutableConfig config = mapper.load(tempFile).value();
        String saved = Files.readString(tempFile);

        assertEquals("supplier-default", config.getName());
        assertEquals(32, config.getLimit());
        assertTrue(saved.contains("server-name: supplier-default"));
        assertTrue(saved.contains("limit: 32"));
    }

    @Test
    void testRuntimeMapperHandlesImmutableConfig() throws IOException {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlMapperFactory factory = YamlMapperFactory.builder().sparrowYaml(sparrowYaml).build();
        YamlMapper<ImmutableConfig> mapper = factory.create(ImmutableConfig.class, () -> new ImmutableConfig("default", 0));

        String yamlContent = """
                server-name: "runtime"
                limit: 64
                """;

        Path tempFile = Files.createTempFile("immutable_config", ".yml");
        Files.writeString(tempFile, yamlContent);

        ImmutableConfig config = mapper.load(tempFile).value();

        assertNotNull(config);
        assertEquals("runtime", config.getName());
        assertEquals(64, config.getLimit());

        mapper.save(tempFile, config);
        String saved = Files.readString(tempFile);
        assertTrue(saved.contains("# Immutable name"));
        assertTrue(saved.contains("server-name: runtime"));
    }

    @Test
    void should_ApplyRecordComponentComments_When_SavingRecordConfig() throws IOException {
        SparrowYaml sparrowYaml = SparrowYaml.builder().build();
        YamlMapperFactory factory = YamlMapperFactory.builder().sparrowYaml(sparrowYaml).build();
        YamlMapper<RecordConfig> mapper = factory.create(RecordConfig.class, () -> new RecordConfig("default", 25565));

        Path tempFile = Files.createTempFile("record_config", ".yml");
        mapper.save(tempFile, new RecordConfig("localhost", 24454));

        String yamlString = Files.readString(tempFile).replace("\r\n", "\n");

        assertTrue(yamlString.contains("# Record host\nhost: localhost"), yamlString);
        assertTrue(yamlString.contains("port:"), yamlString);
        assertTrue(yamlString.contains("24454"), yamlString);
        assertTrue(yamlString.contains("# Record port"), yamlString);
        assertTrue(yamlString.contains("# Generated record port"), yamlString);
    }

    @Test
    void should_ApplyNestedConfigComments_When_SavingConfig() throws IOException {
        AutoSerializerMode[] modes = {AutoSerializerMode.REFLECTION, AutoSerializerMode.ASM};
        for (int i = 0; i < modes.length; i++) {
            SparrowYaml sparrowYaml = SparrowYaml.builder().setAutoSerializerMode(modes[i]).build();
            YamlMapperFactory factory = YamlMapperFactory.builder().sparrowYaml(sparrowYaml).build();
            YamlMapper<NestedCommentConfig> mapper = factory.create(NestedCommentConfig.class, NestedCommentConfig::new);

            Path tempFile = Files.createTempFile("nested_comment_config_" + modes[i].name().toLowerCase(Locale.ROOT), ".yml");
            mapper.save(tempFile, new NestedCommentConfig());

            String saved = Files.readString(tempFile).replace("\r\n", "\n");

            assertTrue(saved.contains("# Do not modify this value\nconfig-version: '1'"), saved);
            assertTrue(saved.contains("\n\n# Synchronization settings\nsynchronization:"), saved);
            assertTrue(saved.contains("  # Number of worker threads handling per-player tasks\n  # Tasks of one player always run on the same worker in submission order\n  worker_threads: 4"), saved);
            assertTrue(saved.contains("  # How long to wait for pending saves\n  shutdown_timeout_seconds: 60"), saved);

            NestedCommentConfig loaded = mapper.load(tempFile).value();
            assertEquals(4, loaded.synchronization.workerThreads);
            assertEquals(60, loaded.synchronization.shutdownTimeoutSeconds);
        }
    }

    @Test
    void should_NotOverflow_When_ConfigTypeIsSelfReferential() throws IOException {
        AutoSerializerMode[] modes = {AutoSerializerMode.REFLECTION, AutoSerializerMode.ASM};
        for (int i = 0; i < modes.length; i++) {
            SparrowYaml sparrowYaml = SparrowYaml.builder().setAutoSerializerMode(modes[i]).build();
            YamlMapperFactory factory = YamlMapperFactory.builder().sparrowYaml(sparrowYaml).build();
            YamlMapper<SelfRefNodeConfig> mapper = factory.create(SelfRefNodeConfig.class, SelfRefNodeConfig::new);

            SelfRefNodeConfig config = new SelfRefNodeConfig();
            config.child = new SelfRefNodeConfig();

            Path tempFile = Files.createTempFile("self_ref_config_" + modes[i].name().toLowerCase(Locale.ROOT), ".yml");
            mapper.save(tempFile, config);

            // 自引用类型的注释只收集到首个层级, 更深层级按环切断
            String saved = Files.readString(tempFile).replace("\r\n", "\n");

            assertTrue(saved.contains("# Node name\nname: root"), saved);
            assertTrue(saved.contains("# Child node\nchild:"), saved);
            assertTrue(saved.contains("child:\n  name: root"), saved);

            SelfRefNodeConfig loaded = mapper.load(tempFile).value();
            assertEquals("root", loaded.name);
            assertEquals("root", loaded.child.name);
        }
    }

    private static void assertEnumFallbackContract(AutoSerializerMode mode, Path tempDir) throws Exception {
        SparrowYaml sparrowYaml = SparrowYaml.builder().setAutoSerializerMode(mode).build();
        YamlMapper<EnumFallbackConfig> mapper = sparrowYaml.mapper(EnumFallbackConfig.class, EnumFallbackConfig::new);
        String modeName = mode.name().toLowerCase(Locale.ROOT);
        Path unknownPath = tempDir.resolve("unknown-enum-" + modeName + ".yml");
        Files.writeString(unknownPath, "compression: ZTSD\nmarker: loaded");

        EnumFallbackConfig fallback = mapper.loadValue(unknownPath);

        assertEquals(CompressionStrategy.ZSTD, fallback.compression);
        assertEquals("loaded", fallback.marker);

        Path emptyPath = tempDir.resolve("empty-enum-" + modeName + ".yml");
        Files.writeString(emptyPath, "compression: ''\nmarker: loaded");
        assertEquals(CompressionStrategy.ZSTD, mapper.loadValue(emptyPath).compression);

        Path knownPath = tempDir.resolve("known-enum-" + modeName + ".yml");
        Files.writeString(knownPath, "compression: deflate\nmarker: loaded");
        assertEquals(CompressionStrategy.DEFLATE, mapper.loadValue(knownPath).compression);

        Path wrongShapePath = tempDir.resolve("wrong-enum-shape-" + modeName + ".yml");
        Files.writeString(wrongShapePath, "compression:\n  value: ZSTD");
        assertThrows(InvalidNodeException.class, () -> mapper.loadValue(wrongShapePath));

        Path listPath = tempDir.resolve("unknown-enum-list-" + modeName + ".yml");
        Files.writeString(listPath, "compression: [ZSTD, ZTSD]");
        YamlMapper<EnumListConfig> listMapper = sparrowYaml.mapper(EnumListConfig.class, EnumListConfig::new);
        assertThrows(InvalidNodeException.class, () -> listMapper.loadValue(listPath));

        Path recordPath = tempDir.resolve("unknown-enum-record-" + modeName + ".yml");
        Files.writeString(recordPath, "compression: ZTSD");
        YamlMapper<EnumRecordConfig> recordMapper = sparrowYaml.mapper(EnumRecordConfig.class, () -> new EnumRecordConfig(CompressionStrategy.ZSTD));
        assertThrows(InvalidNodeException.class, () -> recordMapper.loadValue(recordPath));

        Path unsafePath = tempDir.resolve("unknown-enum-unsafe-" + modeName + ".yml");
        Files.writeString(unsafePath, "compression: ZTSD");
        YamlMapper<UnsafeEnumConfig> unsafeMapper = sparrowYaml.mapper(UnsafeEnumConfig.class, () -> new UnsafeEnumConfig(0));
        assertThrows(InvalidNodeException.class, () -> unsafeMapper.loadValue(unsafePath));

        Path noDefaultPath = tempDir.resolve("unknown-enum-without-default-" + modeName + ".yml");
        Files.writeString(noDefaultPath, "compression: ZTSD");
        YamlMapper<EnumWithoutDefaultConfig> noDefaultMapper = sparrowYaml.mapper(EnumWithoutDefaultConfig.class, EnumWithoutDefaultConfig::new);
        assertThrows(InvalidNodeException.class, () -> noDefaultMapper.loadValue(noDefaultPath));

        Path genericPath = tempDir.resolve("unknown-generic-enum-" + modeName + ".yml");
        Files.writeString(genericPath, "compression: ZTSD");
        YamlMapper<GenericEnumFallbackConfig> genericMapper = sparrowYaml.mapper(GenericEnumFallbackConfig.class, GenericEnumFallbackConfig::new);
        assertEquals(CompressionStrategy.ZSTD, genericMapper.loadValue(genericPath).compression);

        SparrowYaml customYaml = SparrowYaml.builder().setAutoSerializerMode(mode).build();
        customYaml.serializers().register(CompressionStrategy.class, NodeSerializer.createInternal(
                CompressionStrategy.class,
                node -> {
                    throw new InvalidNodeException(node, CompressionStrategy.class);
                },
                Enum::name
        ));
        YamlMapper<EnumFallbackConfig> customMapper = customYaml.mapper(EnumFallbackConfig.class, EnumFallbackConfig::new);
        Path customPath = tempDir.resolve("custom-enum-" + modeName + ".yml");
        Files.writeString(customPath, "compression: DEFLATE");
        assertThrows(InvalidNodeException.class, () -> customMapper.loadValue(customPath));

        SparrowYaml delegatingYaml = SparrowYaml.builder().setAutoSerializerMode(mode).build();
        NodeSerializer<CompressionStrategy> canonical = NodeSerializers.enumCodec(CompressionStrategy.class);
        delegatingYaml.serializers().register(CompressionStrategy.class, NodeSerializer.createInternal(
                CompressionStrategy.class,
                canonical::deserialize,
                Enum::name
        ));
        YamlMapper<EnumFallbackConfig> delegatingMapper = delegatingYaml.mapper(EnumFallbackConfig.class, EnumFallbackConfig::new);
        Path delegatingPath = tempDir.resolve("delegating-enum-" + modeName + ".yml");
        Files.writeString(delegatingPath, "compression: ZTSD");
        assertThrows(InvalidNodeException.class, () -> delegatingMapper.loadValue(delegatingPath));
    }

    private static void withMissingResourcePath(String fileName, ResourcePathTest test) throws Exception {
        withResourcePath(fileName, path -> {
            Files.deleteIfExists(path);
            test.run(path);
        });
    }

    private static void withResourceFile(String fileName, String content, ResourcePathTest test) throws Exception {
        withResourcePath(fileName, path -> {
            Files.writeString(path, content);
            test.run(path);
        });
    }

    private static void withResourcePath(String fileName, ResourcePathTest test) throws Exception {
        Path path = testResourcesDir().resolve(fileName);
        byte[] previousContent = Files.exists(path) ? Files.readAllBytes(path) : null;
        try {
            Files.createDirectories(path.getParent());
            test.run(path);
        } finally {
            if (previousContent == null) {
                Files.deleteIfExists(path);
            } else {
                Files.write(path, previousContent);
            }
        }
    }

    private static Path testResourcesDir() {
        List<Path> candidates = List.of(
                Path.of("src", "test", "resources"),
                Path.of("common", "src", "test", "resources")
        );
        for (Path candidate : candidates) {
            if (Files.isDirectory(candidate)) {
                return candidate;
            }
        }
        throw new IllegalStateException("Cannot locate test resources directory");
    }

    @FunctionalInterface
    private interface ResourcePathTest {
        void run(Path path) throws Exception;
    }
}
