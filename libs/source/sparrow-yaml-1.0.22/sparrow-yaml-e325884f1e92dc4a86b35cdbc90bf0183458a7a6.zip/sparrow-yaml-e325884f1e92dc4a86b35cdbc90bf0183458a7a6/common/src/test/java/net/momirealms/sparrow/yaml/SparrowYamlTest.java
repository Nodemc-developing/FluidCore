package net.momirealms.sparrow.yaml;

import net.momirealms.sparrow.yaml.node.ScalarNode;
import net.momirealms.sparrow.yaml.node.SectionNode;
import net.momirealms.sparrow.yaml.node.SequenceNode;
import net.momirealms.sparrow.yaml.node.YamlNode;
import net.momirealms.sparrow.yaml.route.Route;
import net.momirealms.sparrow.yaml.exception.AlternativesNodeException;
import net.momirealms.sparrow.yaml.exception.InvalidNodeException;
import net.momirealms.sparrow.yaml.exception.MissingNodeException;
import net.momirealms.sparrow.yaml.exception.UnexpectedNodeParsingException;
import net.momirealms.sparrow.yaml.serializer.NodeSerializer;
import net.momirealms.sparrow.yaml.serializer.NodeSerializers;
import net.momirealms.sparrow.yaml.serializer.TypeRef;
import net.momirealms.sparrow.yaml.upgrade.YamlUpgradePipeline;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.snakeyaml.engine.v2.comments.CommentLine;
import org.snakeyaml.engine.v2.comments.CommentType;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.time.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.*;

/**
 * SparrowYaml 核心功能综合测试.
 * 测试用例按功能划分为: 文档 IO、节点读取、节点写入与同步、注释与路由、编解码器组合.
 */
class SparrowYamlTest {

    @Test
    @SuppressWarnings("deprecation")
    void should_SerializeAndDeserialize_TimeAndUUID_Properly() throws Exception {
        SparrowYaml yaml = SparrowYaml.builder().build();
        YamlDocument doc = yaml.load("test: test");
        
        UUID uuid = UUID.randomUUID();
        Date date = new Date();
        Instant instant = Instant.now();
        LocalDate localDate = LocalDate.now();
        LocalTime localTime = LocalTime.now();
        LocalDateTime localDateTime = LocalDateTime.now();
        Duration duration = Duration.ofDays(1);
        Period period = Period.ofDays(2);
        ZonedDateTime zonedDateTime = ZonedDateTime.now();
        Locale localeLanguage = Locale.ENGLISH;
        Locale localeCountry = Locale.US;
        Locale localeVariant = new Locale("zh", "CN", "PINYIN");
        
        doc.setAndGet(UUID.class, uuid, Route.from("uuid"));
        doc.setAndGet(Date.class, date, Route.from("date"));
        doc.setAndGet(Instant.class, instant, Route.from("instant"));
        doc.setAndGet(LocalDate.class, localDate, Route.from("local_date"));
        doc.setAndGet(LocalTime.class, localTime, Route.from("local_time"));
        doc.setAndGet(LocalDateTime.class, localDateTime, Route.from("local_date_time"));
        doc.setAndGet(Duration.class, duration, Route.from("duration"));
        doc.setAndGet(Period.class, period, Route.from("period"));
        doc.setAndGet(ZonedDateTime.class, zonedDateTime, Route.from("zoned_date_time"));
        doc.setAndGet(Locale.class, localeLanguage, Route.from("locale_language"));
        doc.setAndGet(Locale.class, localeCountry, Route.from("locale_country"));
        doc.setAndGet(Locale.class, localeVariant, Route.from("locale_variant"));
        doc.setAndGet(UUID.class, null, Route.from("skipped_uuid"));
        doc.setAndGet(Locale.class, null, Route.from("skipped_locale"));
        doc.setAndGet(LocalDate.class, null, Route.from("skipped_local_date"));
        
        java.io.StringWriter writer = new java.io.StringWriter();
        doc.save(writer);
        String dumped = writer.toString();
        assertFalse(dumped.contains("skipped_uuid:"));
        assertFalse(dumped.contains("skipped_locale:"));
        assertFalse(dumped.contains("skipped_local_date:"));
        
        YamlDocument loadedDoc = yaml.load(dumped);
        
        assertEquals(uuid, loadedDoc.get(java.util.UUID.class, Route.from("uuid")));
        assertEquals(date, loadedDoc.get(java.util.Date.class, Route.from("date")));
        assertEquals(instant, loadedDoc.get(java.time.Instant.class, Route.from("instant")));
        assertEquals(localDate, loadedDoc.get(java.time.LocalDate.class, Route.from("local_date")));
        assertEquals(localTime, loadedDoc.get(java.time.LocalTime.class, Route.from("local_time")));
        assertEquals(localDateTime, loadedDoc.get(java.time.LocalDateTime.class, Route.from("local_date_time")));
        assertEquals(duration, loadedDoc.get(java.time.Duration.class, Route.from("duration")));
        assertEquals(period, loadedDoc.get(java.time.Period.class, Route.from("period")));
        assertEquals(zonedDateTime, loadedDoc.get(java.time.ZonedDateTime.class, Route.from("zoned_date_time")));
        assertEquals(localeLanguage, loadedDoc.get(java.util.Locale.class, Route.from("locale_language")));
        assertEquals(localeCountry, loadedDoc.get(java.util.Locale.class, Route.from("locale_country")));
        assertEquals(localeVariant, loadedDoc.get(java.util.Locale.class, Route.from("locale_variant")));
        assertThrows(MissingNodeException.class, () -> loadedDoc.get(java.util.UUID.class, Route.from("skipped_uuid")));
        assertThrows(MissingNodeException.class, () -> loadedDoc.get(java.util.Locale.class, Route.from("skipped_locale")));
        assertThrows(MissingNodeException.class, () -> loadedDoc.get(java.time.LocalDate.class, Route.from("skipped_local_date")));
    }

    @Nested
    class DocumentIoTests {

        @Test
        void should_LoadYamlDocument_When_ReadingFromResources() throws IOException {
            // 1. 准备阶段 (Arrange)
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();

            // 2. 执行阶段 (Act)
            InputStream resource = SparrowYamlTest.class.getClassLoader().getResourceAsStream("test.yml");
            YamlDocument fromInputStream = sparrowYaml.load(resource);
            YamlDocument fromResource = sparrowYaml.loadFromResource("test.yml");

            // 3. 断言阶段 (Assert)
            assertNotNull(fromInputStream, "从 InputStream 加载文档不应为空");
            assertNotNull(fromResource, "从 Resource 快捷加载文档不应为空");
        }

        @Test
        void should_LoadResourceFromExplicitClassLoaderAndClassAnchor() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.create();
            String resourceName = "isolated-plugin-config.yml";
            byte[] content = "source: plugin-loader\n".getBytes();
            PluginResourceClassLoader classLoader = new PluginResourceClassLoader(resourceName, content);
            Class<?> resourceAnchor = classLoader.defineAnchor(classBytes(PluginResourceAnchor.class));

            assertNull(SparrowYaml.class.getClassLoader().getResourceAsStream(resourceName));
            assertEquals("plugin-loader", sparrowYaml.loadFromResource(classLoader, resourceName).getString(Route.from("source")));
            assertEquals("plugin-loader", sparrowYaml.loadFromResource(resourceAnchor, resourceName).getString(Route.from("source")));
        }

        @Test
        void should_ReturnTrue_When_DocumentIsEmpty() throws IOException {
            // 1. 准备阶段 (Arrange)
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            
            // 2. 执行阶段 (Act)
            YamlDocument yamlDocument = sparrowYaml.load("");
            
            // 3. 断言阶段 (Assert)
            assertTrue(yamlDocument.isEmptyDocument(), "加载空字符串应返回空文档状态");
        }

        @Test
        void should_SkipMappingNullsAndPreserveSequenceNulls_When_DumpingDocument() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            keep: value
            drop: null
            blank:
            nested:
              keep: value
              drop: null
            sequence:
              - first
              - null
              -
              - last
            """);

            StringWriter writer = new StringWriter();
            yamlDocument.save(writer);
            String dumped = writer.toString();

            assertTrue(dumped.contains("keep: value"));
            assertTrue(dumped.contains("- first"));
            assertTrue(dumped.contains("- last"));
            assertFalse(dumped.contains("drop:"));
            assertFalse(dumped.contains("blank:"));
            YamlDocument reloaded = sparrowYaml.load(dumped);
            assertEquals(Arrays.asList("first", null, null, "last"), reloaded.getSequenceOrNull(Route.from("sequence")).getValues());
        }

        @Test
        void should_CreateDefaultFileWithoutBackup_When_UpgradeFileTargetIsMissing() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            Path tempDir = Files.createTempDirectory("sparrow_missing_upgrade");
            Path configPath = tempDir.resolve("config.yml");
            YamlDocument defDocument = sparrowYaml.load("""
                    config-version: 1
                    value: default
                    """);

            YamlDocument upgraded = sparrowYaml.upgradeFile(
                    configPath.toFile(),
                    defDocument,
                    YamlUpgradePipeline.builder().build(),
                    true
            );

            assertSame(defDocument, upgraded);
            assertTrue(Files.exists(configPath));
            assertEquals("default", sparrowYaml.load(configPath).getNodeOrNull(Route.from("value")).value());
            try (var paths = Files.list(tempDir)) {
                assertEquals(1, paths.count(), "目标文件不存在时不应创建备份文件");
            }
        }

        @Test
        void should_CreateParentDirectories_When_UpgradeFileSavesDefaultDocument() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            Path tempDir = Files.createTempDirectory("sparrow_nested_upgrade");
            Path configPath = tempDir.resolve("nested").resolve("config.yml");
            YamlDocument defDocument = sparrowYaml.load("""
                    config-version: 1
                    value: default
                    """);

            YamlDocument upgraded = sparrowYaml.upgradeFile(
                    configPath,
                    defDocument,
                    YamlUpgradePipeline.builder().build(),
                    false
            );

            assertSame(defDocument, upgraded);
            assertTrue(Files.exists(configPath));
            assertEquals("default", sparrowYaml.load(configPath).getNodeOrNull(Route.from("value")).value());
        }

        @Test
        void should_CreateBackup_When_UpgradeFileUsesExplicitBackupPath() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            Path tempDir = Files.createTempDirectory("sparrow_backup_upgrade");
            Path configPath = tempDir.resolve("config.yml");
            Path backupPath = tempDir.resolve("backup").resolve("config.yml.bak");
            Files.writeString(configPath, """
                    config-version: 1
                    old: keep
                    """);
            YamlDocument defDocument = sparrowYaml.load("""
                    config-version: 2
                    value: default
                    """);

            YamlDocument upgraded = sparrowYaml.upgradeFile(
                    configPath,
                    defDocument,
                    YamlUpgradePipeline.builder().build(),
                    backupPath
            );

            assertTrue(Files.exists(backupPath));
            assertTrue(Files.readString(backupPath).contains("old: keep"));
            assertEquals("2", upgraded.getNodeOrNull(Route.from("config-version")).value().toString());
            assertEquals("default", upgraded.getNodeOrNull(Route.from("value")).value());
            assertNull(upgraded.getNodeOrNull(Route.from("old")));
        }

        @Test
        void should_NotResolveBackupOrRewriteFile_When_UpgradeFileVersionIsCurrent() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.create();
            Path configPath = Files.createTempFile("sparrow_current_upgrade", ".yml");
            String original = "config-version: 2\nvalue: local\nlegacy: keep\n";
            Files.writeString(configPath, original);
            FileTime originalModifiedTime = FileTime.fromMillis(1_700_000_000_000L);
            Files.setLastModifiedTime(configPath, originalModifiedTime);
            YamlDocument defDocument = sparrowYaml.load("config-version: 2\nvalue: default\n");
            AtomicInteger resolverCalls = new AtomicInteger();

            YamlDocument loaded = sparrowYaml.upgradeFile(
                    configPath,
                    defDocument,
                    YamlUpgradePipeline.builder().build(),
                    path -> {
                        resolverCalls.incrementAndGet();
                        return path.resolveSibling(path.getFileName() + ".bak");
                    }
            );

            assertEquals("local", loaded.getString(Route.from("value")));
            assertEquals(0, resolverCalls.get());
            assertEquals(original, Files.readString(configPath));
            assertEquals(originalModifiedTime, Files.getLastModifiedTime(configPath));
        }

        @Test
        void should_PassOriginalPathToBackupResolver_When_PathUpgradeIsRequired() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.create();
            Path configPath = Files.createTempFile("sparrow_resolver_upgrade", ".yml");
            Path backupPath = configPath.resolveSibling(configPath.getFileName() + ".bak");
            Files.writeString(configPath, "config-version: 1\nvalue: local\n");
            YamlDocument defDocument = sparrowYaml.load("config-version: 2\nvalue: default\nadded: yes\n");
            AtomicReference<Path> resolvedPath = new AtomicReference<>();

            sparrowYaml.upgradeFile(configPath, defDocument, YamlUpgradePipeline.builder().build(), path -> {
                resolvedPath.set(path);
                return backupPath;
            });

            assertEquals(configPath, resolvedPath.get());
            assertTrue(Files.readString(backupPath).contains("config-version: 1"));
            assertTrue(Files.readString(configPath).contains("config-version: '2'"));
        }

        @Test
        void should_RejectBackupPath_When_ItMatchesLocalFilePath() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            Path configPath = Files.createTempFile("sparrow_same_backup", ".yml");
            Files.writeString(configPath, "config-version: 1\nvalue: local\n");
            YamlDocument defDocument = sparrowYaml.load("config-version: 2\nvalue: default\n");
            YamlUpgradePipeline pipeline = YamlUpgradePipeline.builder().build();

            assertThrows(IllegalArgumentException.class, () -> sparrowYaml.upgradeFile(
                    configPath.toFile(),
                    defDocument,
                    pipeline,
                    configPath
            ));
        }
    }

    private static byte[] classBytes(Class<?> type) throws IOException {
        String resourceName = type.getName().replace('.', '/') + ".class";
        try (InputStream inputStream = type.getClassLoader().getResourceAsStream(resourceName)) {
            return inputStream.readAllBytes();
        }
    }

    private static final class PluginResourceClassLoader extends ClassLoader {
        private final String resourceName;
        private final byte[] resource;

        private PluginResourceClassLoader(String resourceName, byte[] resource) {
            super(ClassLoader.getPlatformClassLoader());
            this.resourceName = resourceName;
            this.resource = resource;
        }

        private Class<?> defineAnchor(byte[] bytes) {
            return this.defineClass(PluginResourceAnchor.class.getName(), bytes, 0, bytes.length);
        }

        @Override
        public InputStream getResourceAsStream(String name) {
            if (this.resourceName.equals(name)) {
                return new ByteArrayInputStream(this.resource);
            }
            return super.getResourceAsStream(name);
        }
    }

    @Nested
    class NodeReadTests {

        @Test
        void should_ReadScalarNode_When_NodeIsSimpleValue() throws IOException {
            // 1. 准备阶段 (Arrange)
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("single-key: \"success!\"");

            // 2. 执行阶段 (Act)
            YamlNode<?> yamlNode = yamlDocument.getNodeOrNull(Route.from("single-key"));
            ScalarNode scalarNode = yamlDocument.getScalarOrNull(Route.from("single-key"));

            // 3. 断言阶段 (Assert)
            assertNotNull(yamlNode);
            assertInstanceOf(ScalarNode.class, yamlNode);
            assertEquals(yamlNode, scalarNode, "按通用节点和 Scalar 节点获取的结果应相同");
            assertEquals("success!", scalarNode.value());
        }

        @Test
        void should_ReadMappingNode_When_NodeIsSection() throws IOException {
            // 1. 准备阶段 (Arrange)
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            mapping-key:
                user: "Catnies"
                id: 114514
            """);

            // 2. 执行阶段 (Act)
            SectionNode sectionNode = yamlDocument.getSectionOrNull(Route.from("mapping-key"));
            ScalarNode userNode = yamlDocument.getScalarOrNull(Route.from("mapping-key", "user"));
            ScalarNode idNode = yamlDocument.getScalarOrNull(Route.from("mapping-key", "id"));

            // 3. 断言阶段 (Assert)
            assertNotNull(sectionNode);
            assertEquals("Catnies", userNode.value());
            assertEquals(114514, idNode.value());
        }

        @Test
        void should_ReadSequenceNode_When_NodeIsList() throws IOException {
            // 1. 准备阶段 (Arrange)
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            list-key:
                - "string"
                - 888
                - map: "value"
                - - "nested"
                  - 100.0
            """);

            // 2. 执行阶段 (Act)
            SequenceNode sequenceNode = yamlDocument.getSequenceOrNull(Route.from("list-key"));
            SequenceNode nestedSequenceNode = yamlDocument.getSequenceOrNull(Route.from("list-key", 3));

            // 3. 断言阶段 (Assert)
            assertNotNull(sequenceNode);
            assertEquals("string", sequenceNode.getScalarOrNull(Route.from(0)).value());
            assertEquals(888, sequenceNode.getScalarOrNull(Route.from(1)).value());
            assertEquals("value", sequenceNode.getSectionOrNull(Route.from(2)).getScalarOrNull(Route.from("map")).value());
            
            assertNotNull(nestedSequenceNode);
            assertEquals("nested", nestedSequenceNode.getScalarOrNull(Route.from(0)).value());
            assertEquals(100.0, nestedSequenceNode.getScalarOrNull(Route.from(1)).value());
        }

        @Test
        void should_ReturnTypedNode_When_UsingGetOrThrow() throws Throwable {
            // 1. 准备阶段 (Arrange)
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            scalar: value
            section:
              key: value
            sequence:
              - item
            """);

            // 2. 执行阶段 (Act) & 3. 断言阶段 (Assert)
            assertEquals("value", yamlDocument.getScalarOrThrow(Route.from("scalar"), null).value());
            assertSame(yamlDocument.getSectionOrNull(Route.from("section")), yamlDocument.getSectionOrThrow(Route.from("section"), null));
            assertSame(yamlDocument.getSequenceOrNull(Route.from("sequence")), yamlDocument.getSequenceOrThrow(Route.from("sequence"), null));
            assertThrows(NoSuchElementException.class, () -> yamlDocument.getScalarOrThrow(Route.from("missing"), null));
            assertThrows(NoSuchElementException.class, () -> yamlDocument.getScalarOrThrow(Route.from("section"), null));
        }

        @Test
        @SuppressWarnings("unchecked")
        void should_RecursivelyExtractRawValues_When_UsingGetValues() throws IOException {
            // 1. 准备阶段 (Arrange)
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            scalar: "value"
            number: 114514
            null-value: null
            section:
                user: "Catnies"
                nested:
                    depth: 2
            sequence:
                - "string"
                - 888
                - map: "value"
                - - "nested"
                  - 100.0
            """);

            // 2. 执行阶段 (Act)
            Map<String, Object> values = yamlDocument.getValues();

            // 3. 断言阶段 (Assert)
            assertEquals(List.of("scalar", "number", "null-value", "section", "sequence"), new ArrayList<>(values.keySet()), "应按键的声明顺序返回");
            assertEquals("value", values.get("scalar"));
            assertEquals(114514, values.get("number"));
            assertNull(values.get("null-value"), "Scalar 的 null 原始值应原样返回");

            Map<String, Object> section = assertInstanceOf(Map.class, values.get("section"));
            assertEquals("Catnies", section.get("user"));
            Map<String, Object> nested = assertInstanceOf(Map.class, section.get("nested"));
            assertEquals(2, nested.get("depth"));

            List<Object> sequence = assertInstanceOf(List.class, values.get("sequence"));
            assertEquals("string", sequence.get(0));
            assertEquals(888, sequence.get(1));
            assertEquals(Map.of("map", "value"), sequence.get(2));
            assertEquals(List.of("nested", 100.0), sequence.get(3));
        }

        @Test
        void should_RepresentYamlNullAsJavaNull() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
                    scalar-null: null
                    section:
                      nested-null: null
                    sequence: [null]
                    """);

            Map<?, ?> represented = assertInstanceOf(Map.class, yamlDocument.representValue());
            Map<?, ?> section = assertInstanceOf(Map.class, represented.get("section"));
            List<?> sequence = assertInstanceOf(List.class, represented.get("sequence"));

            assertNull(yamlDocument.getScalarOrNull(Route.from("scalar-null")).representValue());
            assertTrue(represented.containsKey("scalar-null"));
            assertNull(represented.get("scalar-null"));
            assertTrue(section.containsKey("nested-null"));
            assertNull(section.get("nested-null"));
            assertEquals(1, sequence.size());
            assertNull(sequence.get(0));
        }
    }

    @Nested
    class RouteTests {

        @Test
        void should_ConcatenateRoutes_When_AddingRoute() {
            // 1. 准备阶段 (Arrange)
            Route route = Route.from("root").add(Route.from("child", 1));

            // 2. 执行阶段 (Act) & 3. 断言阶段 (Assert)
            assertEquals(3, route.length());
            assertEquals("root", route.getRouteElement(0).key());
            assertEquals("child", route.getRouteElement(1).key());
            assertEquals(1, route.getRouteElement(2).key());
        }

        @Test
        void should_HashEmptyRoute_When_UsedInCollections() {
            // 1. 准备阶段 (Arrange)
            Set<Route> routes = new HashSet<>();

            // 2. 执行阶段 (Act) & 3. 断言阶段 (Assert)
            assertDoesNotThrow(() -> routes.add(Route.empty()));
            assertTrue(routes.contains(Route.empty()));
        }
    }

    @Nested
    class NodeWriteAndSyncTests {

        @Test
        void should_CreateSubNodes_When_SettingValuesInEmptyDocument() throws IOException {
            // 1. 准备阶段 (Arrange)
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("");

            // 2. 执行阶段 (Act) - 测试 Scalar
            yamlDocument.setSubNode("scalar", "value");
            
            // 2. 执行阶段 (Act) - 测试 Section (Map)
            yamlDocument.setSubNode("section", new LinkedHashMap<>() {{
                this.put("user", "Catnies");
                this.put("id", 114514);
            }});
            
            // 2. 执行阶段 (Act) - 测试 Sequence (List)
            yamlDocument.setSubNode("list", new ArrayList<>() {{
                this.add("hello");
                this.add(100);
            }});

            // 3. 断言阶段 (Assert)
            assertEquals("value", yamlDocument.getScalarOrNull(Route.from("scalar")).value());
            assertEquals("Catnies", yamlDocument.getScalarOrNull(Route.from("section", "user")).value());
            assertEquals(114514, yamlDocument.getScalarOrNull(Route.from("section", "id")).value());
            assertEquals("hello", yamlDocument.getScalarOrNull(Route.from("list", 0)).value());
            assertEquals(100, yamlDocument.getScalarOrNull(Route.from("list", 1)).value());
        }

        @Test
        void should_ReplaceExistingLeaf_When_SettingRoute() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
                    server:
                      host: old
                    items: [old]
                    """);

            YamlNode<?> host = yamlDocument.set(Route.from("server", "host"), "new");
            YamlNode<?> item = yamlDocument.set(Route.from("items", 0), "new");

            assertEquals("new", host.value());
            assertEquals("new", item.value());
            assertEquals("new", yamlDocument.get(String.class, Route.from("server", "host")));
            assertEquals("new", yamlDocument.get(String.class, Route.from("items", 0)));
        }

        @Test
        void should_ReplaceMismatchedIntermediateNode_When_SettingRoute() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
                    mapping: old
                    sequence: old
                    items: [old]
                    """);

            yamlDocument.set(Route.from("mapping", "enabled"), true);
            yamlDocument.set(Route.from("sequence", 1), "second");
            yamlDocument.set(Route.from("items", 0, "name"), "first");

            assertEquals(true, yamlDocument.get(Boolean.class, Route.from("mapping", "enabled")));
            assertEquals("second", yamlDocument.get(String.class, Route.from("sequence", 1)));
            assertEquals("first", yamlDocument.get(String.class, Route.from("items", 0, "name")));
        }

        @Test
        void should_CopyYamlNode_When_SettingItIntoAnotherLocation() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument sourceDocument = sparrowYaml.load("""
                    source:
                      value: original
                    """);
            YamlDocument targetDocument = sparrowYaml.load("");
            SectionNode source = sourceDocument.getSectionOrNull(Route.from("source"));

            SectionNode sameDocumentCopy = (SectionNode) sourceDocument.set(Route.from("copy"), source);
            SectionNode otherDocumentCopy = (SectionNode) targetDocument.set(Route.from("copy"), source);
            sameDocumentCopy.getScalarOrNull(Route.from("value")).setValue("same-document");
            otherDocumentCopy.getScalarOrNull(Route.from("value")).setValue("other-document");

            assertNotSame(source, sameDocumentCopy);
            assertNotSame(source, otherDocumentCopy);
            assertNotSame(source.internalValueNode(), sameDocumentCopy.internalValueNode());
            assertNotSame(source.internalValueNode(), otherDocumentCopy.internalValueNode());
            assertSame(sourceDocument, source.root());
            assertSame(targetDocument, otherDocumentCopy.root());
            assertEquals("original", sourceDocument.get(String.class, Route.from("source", "value")));
            assertEquals("same-document", sourceDocument.get(String.class, Route.from("copy", "value")));
            assertEquals("other-document", targetDocument.get(String.class, Route.from("copy", "value")));

            StringWriter sourceWriter = new StringWriter();
            sourceDocument.save(sourceWriter);
            YamlDocument reloaded = sparrowYaml.load(sourceWriter.toString());
            assertEquals("original", reloaded.get(String.class, Route.from("source", "value")));
            assertEquals("same-document", reloaded.get(String.class, Route.from("copy", "value")));
        }

        @Test
        void should_SynchronizeMappingAliases_When_MutatingSharedNode() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
                    base: &base
                      value: old
                    alias: *base
                    """);

            yamlDocument.getScalarOrNull(Route.from("base", "value")).setValue("new");
            yamlDocument.set(Route.from("base", "added"), true);

            assertSame(yamlDocument.getNodeOrNull(Route.from("base")).internalValueNode(), yamlDocument.getNodeOrNull(Route.from("alias")).internalValueNode());
            assertEquals("new", yamlDocument.get(String.class, Route.from("alias", "value")));
            assertEquals(true, yamlDocument.get(Boolean.class, Route.from("alias", "added")));

            StringWriter writer = new StringWriter();
            yamlDocument.save(writer);
            assertTrue(writer.toString().contains("*"));
            YamlDocument reloaded = sparrowYaml.load(writer.toString());
            assertEquals("new", reloaded.get(String.class, Route.from("base", "value")));
            assertEquals("new", reloaded.get(String.class, Route.from("alias", "value")));
            assertEquals(true, reloaded.get(Boolean.class, Route.from("base", "added")));
            assertEquals(true, reloaded.get(Boolean.class, Route.from("alias", "added")));
        }

        @Test
        void should_SynchronizeSequenceAliases_When_MutatingSharedNode() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
                    base: &base [a]
                    alias: *base
                    """);

            yamlDocument.getSequenceOrNull(Route.from("base")).setSubNode(1, "b");
            yamlDocument.getSequenceOrNull(Route.from("base")).removeSubNode(0);

            assertSame(yamlDocument.getNodeOrNull(Route.from("base")).internalValueNode(), yamlDocument.getNodeOrNull(Route.from("alias")).internalValueNode());
            assertEquals(List.of("b"), yamlDocument.getSequenceOrNull(Route.from("base")).getValues());
            assertEquals(List.of("b"), yamlDocument.getSequenceOrNull(Route.from("alias")).getValues());

            StringWriter writer = new StringWriter();
            yamlDocument.save(writer);
            assertTrue(writer.toString().contains("*"));
            YamlDocument reloaded = sparrowYaml.load(writer.toString());
            assertEquals(List.of("b"), reloaded.getSequenceOrNull(Route.from("base")).getValues());
            assertEquals(List.of("b"), reloaded.getSequenceOrNull(Route.from("alias")).getValues());
        }

        @Test
        void should_AutoFillWithNull_When_SettingSequenceNodeOutOfBound() throws IOException {
            // 1. 准备阶段 (Arrange)
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            sequence:
              - "first"
              - "second"
            """);
            SequenceNode sequenceNode = yamlDocument.getSequenceOrNull(Route.from("sequence"));

            // 2. 执行阶段 (Act)
            sequenceNode.setSubNode(0, "modified_first"); // 修改已有
            sequenceNode.setSubNode(4, "fifth");          // 越界追加

            // 3. 断言阶段 (Assert)
            assertEquals(5, sequenceNode.size(), "越界追加应导致列表扩容至目标大小");
            assertEquals("modified_first", sequenceNode.getScalarOrNull(Route.from(0)).value());
            assertNull(sequenceNode.getScalarOrNull(Route.from(2)).value(), "中间空缺的部分应使用 Null 补全");
            assertNull(sequenceNode.getScalarOrNull(Route.from(3)).value());
            assertEquals("fifth", sequenceNode.getScalarOrNull(Route.from(4)).value());
        }

        @Test
        void should_SyncChanges_When_DumpingDocument() throws IOException {
            // 1. 准备阶段 (Arrange)
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            # Root Comment
            mapping:
              key1: "value1"
            list:
              - "a"
            """);

            // 2. 执行阶段 (Act)
            yamlDocument.getScalarOrNull(Route.from("mapping", "key1")).setValue("modified_value");
            yamlDocument.getSectionOrNull(Route.from("mapping")).setSubNode("new_key", "new_value");
            yamlDocument.getSequenceOrNull(Route.from("list")).setSubNode(1, "b");

            StringWriter writer = new StringWriter();
            yamlDocument.save(writer);
            String dumped = writer.toString();

            // 3. 断言阶段 (Assert)
            assertTrue(dumped.contains("key1: modified_value"), "修改的节点值应被同步");
            assertTrue(dumped.contains("new_key: new_value"), "新增的节点应被同步");
            assertTrue(dumped.contains("- b"), "追加的列表项应被同步");
            assertTrue(dumped.contains("# Root Comment"), "原有的注释应被保留");
        }
    }

    @Nested
    class CommentAndRouteTests {

        @Test
        void should_MaintainComments_When_AddingCommentsProgrammatically() throws IOException {
            // 1. 准备阶段 (Arrange)
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("");
            yamlDocument.setSubNode("test_key", "test_value");
            ScalarNode scalarNode = yamlDocument.getScalarOrNull(Route.from("test_key"));

            // 2. 执行阶段 (Act)
            List<CommentLine> beforeComments = new ArrayList<>();
            beforeComments.add(new CommentLine(Optional.empty(), Optional.empty(), " Before comment", CommentType.BLOCK));
            scalarNode.setBeforeKeyComments(beforeComments);

            List<CommentLine> inlineComments = new ArrayList<>();
            inlineComments.add(new CommentLine(Optional.empty(), Optional.empty(), " Inline comment", CommentType.IN_LINE));
            scalarNode.setInlineValueComments(inlineComments);

            StringWriter writer = new StringWriter();
            yamlDocument.save(writer);
            String dumped = writer.toString();

            // 3. 断言阶段 (Assert)
            assertTrue(dumped.contains("test_key: test_value"));
            assertTrue(dumped.contains("# Inline comment"), "内联注释应被正确渲染");
        }

        @Test
        void should_PreserveInlineComment_When_UpdatingScalarValue() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("key: old # keep me");

            yamlDocument.getScalarOrNull(Route.from("key")).setValue("new");
            StringWriter writer = new StringWriter();
            yamlDocument.save(writer);

            assertTrue(writer.toString().contains("key: new # keep me"));
        }

        @Test
        void should_KeepRoutesIndependent_When_NodeIsCopied() throws IOException {
            // 1. 准备阶段 (Arrange)
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("");

            // 2. 执行阶段 (Act) - 创建 A.B.C
            yamlDocument.set(Route.from("A", "B", "C"), "value");
            ScalarNode nodeC = yamlDocument.getScalarOrNull(Route.from("A", "B", "C"));
            assertEquals(Route.from("A", "B", "C"), nodeC.route(), "初始路由应匹配");

            // 将 B 节点复制到 D 下
            SectionNode nodeB = yamlDocument.getSectionOrNull(Route.from("A", "B"));
            yamlDocument.setSubNode("D", SectionNode.createEmpty(yamlDocument));
            SectionNode nodeD = yamlDocument.getSectionOrNull(Route.from("D"));

            nodeD.setSubNode("B", nodeB);
            ScalarNode copiedNodeC = yamlDocument.getScalarOrNull(Route.from("D", "B", "C"));

            // 3. 断言阶段 (Assert)
            assertNotSame(nodeC, copiedNodeC);
            assertEquals(Route.from("A", "B", "C"), nodeC.route(), "源节点的路由不应被复制操作改变");
            assertEquals(Route.from("D", "B", "C"), copiedNodeC.route(), "复制节点的路由应反映新位置");
        }
        
        @Test
        void should_CopyCommentsAndStyle_When_UsingNodeUtilities() throws IOException {
            // 1. 准备阶段 (Arrange)
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            source: [1, 2]
            target:
              - 3
              - 4
            """);

            SequenceNode source = yamlDocument.getSequenceOrNull(Route.from("source"));
            SequenceNode target = yamlDocument.getSequenceOrNull(Route.from("target"));

            // 给源节点添加内联注释
            List<CommentLine> inlineComments = new ArrayList<>();
            inlineComments.add(new CommentLine(Optional.empty(), Optional.empty(), " copied", CommentType.IN_LINE));
            source.getScalarOrNull(Route.from(0)).setInlineValueComments(inlineComments);

            // 2. 执行阶段 (Act)
            source.deepCopyCommentsTo(target);
            source.preserveFlowStyleTo(target);

            // 3. 断言阶段 (Assert)
            assertEquals(" copied", target.getScalarOrNull(Route.from(0)).inlineValueComments().get(0).getValue(), "注释应被深拷贝至目标节点");
            
            StringWriter writer = new StringWriter();
            yamlDocument.save(writer);
            assertTrue(writer.toString().contains("target: [3, 4]"), "Flow style 应被同步，使得 target 也变为单行数组格式");
        }
    }

    @Nested
    class CodecCombinatorTests {

        record Block(int x, int y, int z) {
            public List<Integer> toList() {
                return List.of(x, y, z);
            }

            static Block fromPackedLong(long value) {
                int x = (int) (value / 1_000_000L);
                int y = (int) ((value / 1_000L) % 1_000L);
                int z = (int) (value % 1_000L);
                return new Block(x, y, z);
            }

            long asPackedLong() {
                return x * 1_000_000L + y * 1_000L + z;
            }

            static Block fromCsv(String value) {
                String[] parts = value.split(",", 3);
                if (parts.length != 3) {
                    throw new IllegalArgumentException("Expected x,y,z");
                }
                return new Block(
                        Integer.parseInt(parts[0].trim()),
                        Integer.parseInt(parts[1].trim()),
                        Integer.parseInt(parts[2].trim())
                );
            }

            String asCsv() {
                return x + "," + y + "," + z;
            }
        }

        record OptionalBlock(int x, int y, Optional<String> world) {}

        record NamedValue(String value) {}

        enum Mode {
            EASY,
            HARD
        }

        private NodeSerializer<Block> blockPrimaryMappingCodec() {
            return NodeSerializers.mapping(Block.class)
                    .group(
                            NodeSerializers.INT.required("x").forGetter(Block::x),
                            NodeSerializers.INT.required("y").forGetter(Block::y),
                            NodeSerializers.INT.required("z").forGetter(Block::z)
                    )
                    .apply(Block::new)
                    .withAlternative(blockSequenceCodec())
                    .withAlternative(NodeSerializers.LONG, Block::fromPackedLong)
                    .withAlternative(NodeSerializers.STRING, Block::fromCsv);
        }

        private NodeSerializer<Block> blockSequenceCodec() {
            return NodeSerializers.sequence(Block.class)
                    .group(
                            NodeSerializers.INT.required(0).forGetter(Block::x),
                            NodeSerializers.INT.required(1).forGetter(Block::y),
                            NodeSerializers.INT.required(2).forGetter(Block::z)
                    )
                    .apply(Block::new);
        }

        private NodeSerializer<Block> blockPrimarySequenceCodec() {
            return blockSequenceCodec()
                    .withAlternative(NodeSerializers.mapping(Block.class)
                            .group(
                                    NodeSerializers.INT.required("x").forGetter(Block::x),
                                    NodeSerializers.INT.required("y").forGetter(Block::y),
                                    NodeSerializers.INT.required("z").forGetter(Block::z)
                            )
                            .apply(Block::new))
                    .withAlternative(NodeSerializers.LONG, Block::fromPackedLong)
                    .withAlternative(NodeSerializers.STRING, Block::fromCsv);
        }

        private NodeSerializer<Block> blockPrimaryScalarCodec() {
            return NodeSerializers.LONG
                    .xmap(Block.class, Block::fromPackedLong, Block::asPackedLong)
                    .withAlternative(NodeSerializers.mapping(Block.class)
                            .group(
                                    NodeSerializers.INT.required("x").forGetter(Block::x),
                                    NodeSerializers.INT.required("y").forGetter(Block::y),
                                    NodeSerializers.INT.required("z").forGetter(Block::z)
                            )
                            .apply(Block::new))
                    .withAlternative(blockSequenceCodec())
                    .withAlternative(NodeSerializers.STRING, Block::fromCsv);
        }

        @Test
        void should_DecodeMapOfList_When_UsingCombinatorCodec() throws IOException {
            // 1. 准备阶段 (Arrange)
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            users:
              user1:
                - "read"
                - "write"
              user2:
                - "read"
            """);

            // 2. 执行阶段 (Act)
            NodeSerializer<List<String>> stringListCodec = NodeSerializers.STRING.listOf();
            NodeSerializer<java.util.Map<String, List<String>>> mapOfListCodec = stringListCodec.mapOf();
            java.util.Map<String, List<String>> users = yamlDocument.get(mapOfListCodec, Route.from("users"));

            // 3. 断言阶段 (Assert)
            assertNotNull(users);
            assertEquals(2, users.size());
            assertEquals(List.of("read", "write"), users.get("user1"));
            assertEquals(List.of("read"), users.get("user2"));
        }

        @Test
        void should_DecodeCustomObject_When_UsingXmapCombinator() throws IOException {
            // 1. 准备阶段 (Arrange)
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            data:
              block: [1, 2, 3]
            """);

            // 2. 执行阶段 (Act)
            NodeSerializer<Block> blockCodec = NodeSerializers.INT.listOf().xmap(
                    it -> new Block(it.get(0), it.get(1), it.get(2)),
                    Block::toList
            );
            Block block = yamlDocument.get(blockCodec, Route.from("data", "block"));

            // 3. 断言阶段 (Assert)
            assertNotNull(block);
            assertEquals(1, block.x());
            assertEquals(2, block.y());
            assertEquals(3, block.z());
        }

        @Test
        void should_RoundTripMappingObject_When_UsingMappingBuilder() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<Block> blockCodec = NodeSerializers.mapping(Block.class)
                    .group(
                            NodeSerializers.INT.required("x").forGetter(Block::x),
                            NodeSerializers.INT.required("y").forGetter(Block::y),
                            NodeSerializers.INT.required("z").forGetter(Block::z)
                    )
                    .apply(Block::new);
            sparrowYaml.serializers().register(Block.class, blockCodec);

            YamlDocument yamlDocument = sparrowYaml.load("""
            data:
              block:
                x: 1
                y: 2
                z: 3
            """);

            Block decoded = yamlDocument.get(Block.class, Route.from("data", "block"));
            assertEquals(new Block(1, 2, 3), decoded);

            yamlDocument.setAndGet(Block.class, new Block(4, 5, 6), Route.from("data", "other"));
            assertEquals(4, yamlDocument.get(NodeSerializers.INT, Route.from("data", "other", "x")));
            assertEquals(5, yamlDocument.get(NodeSerializers.INT, Route.from("data", "other", "y")));
            assertEquals(6, yamlDocument.get(NodeSerializers.INT, Route.from("data", "other", "z")));
        }

        @Test
        void should_RoundTripSequenceObject_When_UsingSequenceBuilder() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<Block> blockCodec = NodeSerializers.sequence(Block.class)
                    .group(
                            NodeSerializers.INT.required(0).forGetter(Block::x),
                            NodeSerializers.INT.required(1).forGetter(Block::y),
                            NodeSerializers.INT.required(2).forGetter(Block::z)
                    )
                    .apply(Block::new);
            sparrowYaml.serializers().register(Block.class, blockCodec);

            YamlDocument yamlDocument = sparrowYaml.load("""
            data:
              block: [1, 2, 3]
            """);

            Block decoded = yamlDocument.get(Block.class, Route.from("data", "block"));
            assertEquals(new Block(1, 2, 3), decoded);

            yamlDocument.setAndGet(Block.class, new Block(4, 5, 6), Route.from("data", "other"));
            assertEquals(List.of(4, 5, 6), yamlDocument.get(NodeSerializers.INT.listOf(), Route.from("data", "other")));
        }

        @Test
        void should_ThrowMissingException_When_RequiredBuilderFieldIsMissing() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<Block> blockCodec = NodeSerializers.mapping(Block.class)
                    .group(
                            NodeSerializers.INT.required("x").forGetter(Block::x),
                            NodeSerializers.INT.required("y").forGetter(Block::y),
                            NodeSerializers.INT.required("z").forGetter(Block::z)
                    )
                    .apply(Block::new);

            YamlDocument yamlDocument = sparrowYaml.load("""
            block:
              x: 1
              z: 3
            """);

            MissingNodeException missing = assertThrows(MissingNodeException.class, () -> yamlDocument.get(blockCodec, Route.from("block")));
            assertEquals("y", missing.key());
            assertEquals(Route.from("block", "y"), missing.path());
            assertEquals(Integer.class, missing.targetType());
            assertEquals("Missing YAML value 'y' at path \"block.y\", expected Integer", missing.getMessage());
        }

        @Test
        void should_UseDefaultWhenBuilderFieldIsMissingOrNull_AndThrowWhenInvalid() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<Block> blockCodec = NodeSerializers.mapping(Block.class)
                    .group(
                            NodeSerializers.INT.required("x").forGetter(Block::x),
                            NodeSerializers.INT.optional("y", 64).forGetter(Block::y),
                            NodeSerializers.INT.required("z").forGetter(Block::z)
                    )
                    .apply(Block::new);

            YamlDocument missing = sparrowYaml.load("""
            block:
              x: 1
              z: 3
            """);
            assertEquals(new Block(1, 64, 3), missing.get(blockCodec, Route.from("block")));

            YamlDocument nullValue = sparrowYaml.load("""
            block:
              x: 1
              y: null
              z: 3
            """);
            assertEquals(new Block(1, 64, 3), nullValue.get(blockCodec, Route.from("block")));

            YamlDocument invalid = sparrowYaml.load("""
            block:
              x: 1
              y:
                nested: true
              z: 3
            """);
            InvalidNodeException failure = assertThrows(InvalidNodeException.class, () -> invalid.get(blockCodec, Route.from("block")));
            assertEquals(Route.from("block", "y"), failure.path());
            assertEquals(SectionNode.class, failure.actualType());
            assertEquals(Integer.class, failure.targetType());
            assertEquals("Invalid YAML value at path \"block.y\": actual Map, expected Integer", failure.getMessage());
        }

        @Test
        void should_DecodeOptionalBuilderFieldAsOptionalValue() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<OptionalBlock> blockCodec = NodeSerializers.mapping(OptionalBlock.class)
                    .group(
                            NodeSerializers.INT.required("x").forGetter(OptionalBlock::x),
                            NodeSerializers.INT.optional("y", 64).forGetter(OptionalBlock::y),
                            NodeSerializers.STRING.optional("world").forGetter(OptionalBlock::world)
                    )
                    .apply(OptionalBlock::new);
            YamlDocument yamlDocument = sparrowYaml.load("""
            present:
              x: 1
              y: 2
              world: overworld
            missing:
              x: 3
            null-value:
              x: 4
              world: null
            invalid:
              x: 5
              world:
                nested: true
            """);

            assertEquals(new OptionalBlock(1, 2, Optional.of("overworld")), yamlDocument.get(blockCodec, Route.from("present")));
            assertEquals(new OptionalBlock(3, 64, Optional.empty()), yamlDocument.get(blockCodec, Route.from("missing")));
            assertEquals(new OptionalBlock(4, 64, Optional.empty()), yamlDocument.get(blockCodec, Route.from("null-value")));
            assertThrows(InvalidNodeException.class, () -> yamlDocument.get(blockCodec, Route.from("invalid")));
        }

        @Test
        void should_DecodeOptionalBuilderElementAsOptionalValue() throws IOException {
            record OptionalSequence(int x, int y, Optional<Integer> z) {}

            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<OptionalSequence> blockCodec = NodeSerializers.sequence(OptionalSequence.class)
                    .group(
                            NodeSerializers.INT.required(0).forGetter(OptionalSequence::x),
                            NodeSerializers.INT.optional(1, 64).forGetter(OptionalSequence::y),
                            NodeSerializers.INT.optional(2).forGetter(OptionalSequence::z)
                    )
                    .apply(OptionalSequence::new);
            YamlDocument yamlDocument = sparrowYaml.load("""
            present: [1, 2, 3]
            missing: [4]
            null-value: [5, null, null]
            invalid: [6, 7, nope]
            """);

            assertEquals(new OptionalSequence(1, 2, Optional.of(3)), yamlDocument.get(blockCodec, Route.from("present")));
            assertEquals(new OptionalSequence(4, 64, Optional.empty()), yamlDocument.get(blockCodec, Route.from("missing")));
            assertEquals(new OptionalSequence(5, 64, Optional.empty()), yamlDocument.get(blockCodec, Route.from("null-value")));
            assertThrows(InvalidNodeException.class, () -> yamlDocument.get(blockCodec, Route.from("invalid")));
        }

        @Test
        void should_OmitTrailingOptionalEmptyElement_When_EncodingSequence() {
            record OptionalTail(int x, int y, Optional<Integer> z) {}

            NodeSerializer<OptionalTail> blockCodec = NodeSerializers.sequence(OptionalTail.class)
                    .group(
                            NodeSerializers.INT.required(0).forGetter(OptionalTail::x),
                            NodeSerializers.INT.optional(1, 64).forGetter(OptionalTail::y),
                            NodeSerializers.INT.optional(2).forGetter(OptionalTail::z)
                    )
                    .apply(OptionalTail::new);

            assertEquals(List.of(1, 64), blockCodec.serialize(new OptionalTail(1, 64, Optional.empty())));
            assertEquals(List.of(1, 64, 3), blockCodec.serialize(new OptionalTail(1, 64, Optional.of(3))));
        }

        @Test
        void should_RejectMiddleOptionalEmptyElement_When_EncodingSequence() {
            record OptionalMiddle(int x, Optional<Integer> y, int z) {}

            NodeSerializer<OptionalMiddle> blockCodec = NodeSerializers.sequence(OptionalMiddle.class)
                    .group(
                            NodeSerializers.INT.required(0).forGetter(OptionalMiddle::x),
                            NodeSerializers.INT.optional(1).forGetter(OptionalMiddle::y),
                            NodeSerializers.INT.required(2).forGetter(OptionalMiddle::z)
                    )
                    .apply(OptionalMiddle::new);

            InvalidNodeException failure = assertThrows(
                    InvalidNodeException.class,
                    () -> blockCodec.serialize(new OptionalMiddle(1, Optional.empty(), 3))
            );
            assertEquals(Integer.class, failure.targetType());
        }

        @Test
        void should_RejectSparseSequenceIndices_When_EncodingSequence() {
            record SparseElement(int z) {}

            NodeSerializer<SparseElement> blockCodec = NodeSerializers.sequence(SparseElement.class)
                    .group(
                            NodeSerializers.INT.required(2).forGetter(SparseElement::z)
                    )
                    .apply(SparseElement::new);

            InvalidNodeException failure = assertThrows(InvalidNodeException.class, () -> blockCodec.serialize(new SparseElement(3)));
            assertEquals(SparseElement.class, failure.targetType());
        }

        @Test
        void should_RejectNullRequiredElement_When_EncodingSequence() {
            record NullableElement(Integer x) {}

            NodeSerializer<NullableElement> blockCodec = NodeSerializers.sequence(NullableElement.class)
                    .group(
                            NodeSerializers.INT.required(0).forGetter(NullableElement::x)
                    )
                    .apply(NullableElement::new);

            InvalidNodeException failure = assertThrows(InvalidNodeException.class, () -> blockCodec.serialize(new NullableElement(null)));
            assertEquals(Integer.class, failure.targetType());
        }

        @Test
        void should_LetOnFailOverrideRequiredMissingOrInvalidValue() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<Block> blockCodec = NodeSerializers.mapping(Block.class)
                    .group(
                            NodeSerializers.INT.required("x").onFail(failure -> 10).forGetter(Block::x),
                            NodeSerializers.INT.required("y").onFail(failure -> 20).forGetter(Block::y),
                            NodeSerializers.INT.required("z").forGetter(Block::z)
                    )
                    .apply(Block::new);
            YamlDocument yamlDocument = sparrowYaml.load("""
            block:
              x: null
              y:
                nested: true
              z: 3
            """);

            assertEquals(new Block(10, 20, 3), yamlDocument.get(blockCodec, Route.from("block")));
        }

        @Test
        void should_ThrowMissingException_When_RequiredBuilderElementIsMissing() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<Block> blockCodec = NodeSerializers.sequence(Block.class)
                    .group(
                            NodeSerializers.INT.required(0).forGetter(Block::x),
                            NodeSerializers.INT.required(1).forGetter(Block::y),
                            NodeSerializers.INT.required(2).forGetter(Block::z)
                    )
                    .apply(Block::new);

            YamlDocument yamlDocument = sparrowYaml.load("""
            block:
              - 1
              - 2
            """);

            MissingNodeException missing = assertThrows(MissingNodeException.class, () -> yamlDocument.get(blockCodec, Route.from("block")));
            assertEquals(2, missing.key());
            assertEquals(Route.from("block", 2), missing.path());
            assertEquals(Integer.class, missing.targetType());
            assertEquals("Missing YAML list index 2 at path \"block[2]\", expected Integer", missing.getMessage());
        }

        @Test
        void should_TreatNullBuilderFieldAndElementAsMissing() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<Block> mappingCodec = NodeSerializers.mapping(Block.class)
                    .group(
                            NodeSerializers.INT.required("x").forGetter(Block::x),
                            NodeSerializers.INT.required("y").forGetter(Block::y),
                            NodeSerializers.INT.required("z").forGetter(Block::z)
                    )
                    .apply(Block::new);
            NodeSerializer<Block> sequenceCodec = NodeSerializers.sequence(Block.class)
                    .group(
                            NodeSerializers.INT.required(0).forGetter(Block::x),
                            NodeSerializers.INT.required(1).forGetter(Block::y),
                            NodeSerializers.INT.required(2).forGetter(Block::z)
                    )
                    .apply(Block::new);
            YamlDocument yamlDocument = sparrowYaml.load("""
            mapping:
              x: 1
              y: null
              z: 3
            sequence: [1, null, 3]
            """);

            MissingNodeException fieldMissing = assertThrows(MissingNodeException.class, () -> yamlDocument.get(mappingCodec, Route.from("mapping")));
            assertEquals("y", fieldMissing.key());
            assertEquals(Route.from("mapping", "y"), fieldMissing.path());

            MissingNodeException elementMissing = assertThrows(MissingNodeException.class, () -> yamlDocument.get(sequenceCodec, Route.from("sequence")));
            assertEquals(1, elementMissing.key());
            assertEquals(Route.from("sequence", 1), elementMissing.path());
            assertEquals("Missing YAML list index 1 at path \"sequence[1]\", expected Integer", elementMissing.getMessage());
        }

        @Test
        void should_ThrowInvalidException_When_BuilderRootNodeKindIsWrong() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<Block> mappingCodec = NodeSerializers.mapping(Block.class)
                    .group(
                            NodeSerializers.INT.required("x").forGetter(Block::x),
                            NodeSerializers.INT.required("y").forGetter(Block::y),
                            NodeSerializers.INT.required("z").forGetter(Block::z)
                    )
                    .apply(Block::new);
            NodeSerializer<Block> sequenceCodec = NodeSerializers.sequence(Block.class)
                    .group(
                            NodeSerializers.INT.required(0).forGetter(Block::x),
                            NodeSerializers.INT.required(1).forGetter(Block::y),
                            NodeSerializers.INT.required(2).forGetter(Block::z)
                    )
                    .apply(Block::new);

            YamlDocument yamlDocument = sparrowYaml.load("""
            sequence: [1, 2, 3]
            mapping:
              x: 1
              y: 2
              z: 3
            """);

            InvalidNodeException mappingFailure = assertThrows(
                    InvalidNodeException.class,
                    () -> yamlDocument.get(mappingCodec, Route.from("sequence"))
            );
            assertEquals(Route.from("sequence"), mappingFailure.path());
            assertEquals(SequenceNode.class, mappingFailure.actualType());
            assertEquals(Block.class, mappingFailure.targetType());
            assertEquals("Invalid YAML value at path \"sequence\": actual List, expected Block", mappingFailure.getMessage());

            InvalidNodeException sequenceFailure = assertThrows(
                    InvalidNodeException.class,
                    () -> yamlDocument.get(sequenceCodec, Route.from("mapping"))
            );
            assertEquals(Route.from("mapping"), sequenceFailure.path());
            assertEquals(SectionNode.class, sequenceFailure.actualType());
            assertEquals(Block.class, sequenceFailure.targetType());
            assertEquals("Invalid YAML value at path \"mapping\": actual Map, expected Block", sequenceFailure.getMessage());
        }

        @Test
        void should_UseFallback_When_BuilderFieldIsMissingOrInvalid() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            List<RuntimeException> failures = new ArrayList<>();
            NodeSerializer<Block> blockCodec = NodeSerializers.mapping(Block.class)
                    .group(
                            NodeSerializers.INT.required("x").onFail(failure -> {
                                failures.add(failure);
                                return 10;
                            }).forGetter(Block::x),
                            NodeSerializers.INT.required("y").onFail(failure -> {
                                failures.add(failure);
                                return 20;
                            }).forGetter(Block::y),
                            NodeSerializers.INT.required("z").forGetter(Block::z)
                    )
                    .apply(Block::new);

            YamlDocument yamlDocument = sparrowYaml.load("""
            block:
              x:
                bad: true
              z: 3
            """);

            assertEquals(new Block(10, 20, 3), yamlDocument.get(blockCodec, Route.from("block")));
            InvalidNodeException invalid = assertInstanceOf(InvalidNodeException.class, failures.get(0));
            assertEquals(Route.from("block", "x"), invalid.path());
            assertEquals(SectionNode.class, invalid.actualType());
            assertEquals(Integer.class, invalid.targetType());
            MissingNodeException missing = assertInstanceOf(MissingNodeException.class, failures.get(1));
            assertEquals("y", missing.key());
            assertEquals(Route.from("block", "y"), missing.path());
            assertEquals(Integer.class, missing.targetType());
        }

        @Test
        void should_UseFallback_When_BuilderElementIsMissingOrInvalid() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            List<RuntimeException> failures = new ArrayList<>();
            NodeSerializer<Block> blockCodec = NodeSerializers.sequence(Block.class)
                    .group(
                            NodeSerializers.INT.required(0).onFail(failure -> {
                                failures.add(failure);
                                return 10;
                            }).forGetter(Block::x),
                            NodeSerializers.INT.required(1).forGetter(Block::y),
                            NodeSerializers.INT.required(2).onFail(failure -> {
                                failures.add(failure);
                                return 30;
                            }).forGetter(Block::z)
                    )
                    .apply(Block::new);

            YamlDocument yamlDocument = sparrowYaml.load("""
            block:
              - {bad: true}
              - 20
            """);

            assertEquals(new Block(10, 20, 30), yamlDocument.get(blockCodec, Route.from("block")));
            InvalidNodeException invalid = assertInstanceOf(InvalidNodeException.class, failures.get(0));
            assertEquals(Route.from("block", 0), invalid.path());
            assertEquals(SectionNode.class, invalid.actualType());
            assertEquals(Integer.class, invalid.targetType());
            MissingNodeException missing = assertInstanceOf(MissingNodeException.class, failures.get(1));
            assertEquals(2, missing.key());
            assertEquals(Route.from("block", 2), missing.path());
            assertEquals(Integer.class, missing.targetType());
        }

        @Test
        void should_PassSerializerExceptionToFallback_When_DelegateThrows() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            List<RuntimeException> failures = new ArrayList<>();
            NodeSerializer<Integer> throwingInt = NodeSerializers.STRING.xmap(
                    value -> {
                        throw new InvalidNodeException(Route.from("inner"), String.class, Integer.class);
                    },
                    String::valueOf
            );
            NodeSerializer<Block> blockCodec = NodeSerializers.mapping(Block.class)
                    .group(
                            throwingInt.required("x").onFail(failure -> {
                                failures.add(failure);
                                return 10;
                            }).forGetter(Block::x),
                            NodeSerializers.INT.required("y").forGetter(Block::y),
                            NodeSerializers.INT.required("z").forGetter(Block::z)
                    )
                    .apply(Block::new);

            YamlDocument yamlDocument = sparrowYaml.load("""
            block:
              x: 1
              y: 2
              z: 3
            """);

            assertEquals(new Block(10, 2, 3), yamlDocument.get(blockCodec, Route.from("block")));
            assertEquals(1, failures.size());
            InvalidNodeException invalid = assertInstanceOf(InvalidNodeException.class, failures.get(0));
            assertEquals(Route.from("inner"), invalid.path());
            assertEquals(String.class, invalid.actualType());
            assertEquals(Integer.class, invalid.targetType());
        }

        @Test
        void should_DecodeSetInEncounterOrder_When_UsingSetOf() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            tags:
              - alpha
              - beta
              - alpha
            """);

            Set<String> tags = yamlDocument.get(NodeSerializers.STRING.setOf(), Route.from("tags"));

            assertEquals(List.of("alpha", "beta"), new ArrayList<>(tags));
        }

        @Test
        void should_ThrowInvalidException_When_CollectionCombinatorRootNodeKindIsWrong() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            scalar: value
            mapping:
              key: value
            sequence:
              - value
            """);

            InvalidNodeException listFailure = assertThrows(
                    InvalidNodeException.class,
                    () -> yamlDocument.get(NodeSerializers.STRING.listOf(), Route.from("mapping"))
            );
            assertEquals(Route.from("mapping"), listFailure.path());
            assertEquals(SectionNode.class, listFailure.actualType());
            assertEquals(List.class, listFailure.targetType());

            InvalidNodeException setFailure = assertThrows(
                    InvalidNodeException.class,
                    () -> yamlDocument.get(NodeSerializers.STRING.setOf(), Route.from("scalar"))
            );
            assertEquals(Route.from("scalar"), setFailure.path());
            assertEquals(String.class, setFailure.actualType());
            assertEquals(Set.class, setFailure.targetType());

            InvalidNodeException mapFailure = assertThrows(
                    InvalidNodeException.class,
                    () -> yamlDocument.get(NodeSerializers.STRING.mapOf(), Route.from("sequence"))
            );
            assertEquals(Route.from("sequence"), mapFailure.path());
            assertEquals(SequenceNode.class, mapFailure.actualType());
            assertEquals(Map.class, mapFailure.targetType());
        }

        @Test
        void should_ThrowInvalidException_When_NodeValueIsNull() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            blank:
            explicit: null
            """);

            InvalidNodeException blankFailure = assertThrows(
                    InvalidNodeException.class,
                    () -> yamlDocument.get(NodeSerializers.STRING, Route.from("blank"))
            );
            assertEquals(Route.from("blank"), blankFailure.path());
            assertNull(blankFailure.actualType());
            assertEquals(String.class, blankFailure.targetType());

            InvalidNodeException explicitFailure = assertThrows(
                    InvalidNodeException.class,
                    () -> yamlDocument.get(NodeSerializers.OBJECT, Route.from("explicit"))
            );
            assertEquals(Route.from("explicit"), explicitFailure.path());
            assertNull(explicitFailure.actualType());
            assertEquals(Object.class, explicitFailure.targetType());
        }

        @Test
        void should_ThrowInvalidException_When_StringBackedReadsEmptyString() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            uuid: ''
            """);

            InvalidNodeException failure = assertThrows(
                    InvalidNodeException.class,
                    () -> yamlDocument.get(NodeSerializers.UUID, Route.from("uuid"))
            );
            assertEquals(Route.from("uuid"), failure.path());
            assertEquals(String.class, failure.actualType());
            assertEquals(UUID.class, failure.targetType());
        }

        @Test
        void should_HandleXmapMapperNullAndUnexpectedFailure() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            value: cat
            """);

            NodeSerializer<NamedValue> nullingCodec = NodeSerializers.STRING.xmap(
                    value -> null,
                    NamedValue::value
            );
            InvalidNodeException nullFailure = assertThrows(
                    InvalidNodeException.class,
                    () -> yamlDocument.get(nullingCodec, Route.from("value"))
            );
            assertEquals(Route.from("value"), nullFailure.path());
            assertEquals(String.class, nullFailure.actualType());
            assertEquals(Object.class, nullFailure.targetType());

            IllegalArgumentException cause = new IllegalArgumentException("bad value");
            NodeSerializer<NamedValue> throwingCodec = NodeSerializers.STRING.xmap(
                    value -> {
                        throw cause;
                    },
                    NamedValue::value
            );
            UnexpectedNodeParsingException throwingFailure = assertThrows(
                    UnexpectedNodeParsingException.class,
                    () -> yamlDocument.get(throwingCodec, Route.from("value"))
            );
            assertEquals(Route.from("value"), throwingFailure.path());
            assertEquals(String.class, throwingFailure.actualType());
            assertEquals(Object.class, throwingFailure.targetType());
            assertSame(cause, throwingFailure.getCause());
        }

        @Test
        void should_WrapUnexpectedRuntimeException_When_DeserializerFailsDirectly() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            value: cat
            """);
            NullPointerException cause = new NullPointerException("boom");
            NodeSerializer<NamedValue> throwingCodec = NodeSerializers.STRING.xmap(
                    NamedValue.class,
                    value -> {
                        throw cause;
                    },
                    NamedValue::value
            );

            UnexpectedNodeParsingException failure = assertThrows(
                    UnexpectedNodeParsingException.class,
                    () -> yamlDocument.get(throwingCodec, Route.from("value"))
            );
            assertEquals(Route.from("value"), failure.path());
            assertEquals(String.class, failure.actualType());
            assertEquals(NamedValue.class, failure.targetType());
            assertSame(cause, failure.getCause());
        }

        @Test
        void should_LetOnFailHandleUnexpectedMappingFieldFailure() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            IllegalStateException cause = new IllegalStateException("field broke");
            List<RuntimeException> failures = new ArrayList<>();
            NodeSerializer<Integer> throwingInt = NodeSerializer.createInternal(
                    Integer.class,
                    node -> {
                        throw cause;
                    },
                    value -> value
            );
            NodeSerializer<Block> blockCodec = NodeSerializers.mapping(Block.class)
                    .group(
                            throwingInt.required("x").onFail(failure -> {
                                failures.add(failure);
                                return 10;
                            }).forGetter(Block::x),
                            NodeSerializers.INT.required("y").forGetter(Block::y),
                            NodeSerializers.INT.required("z").forGetter(Block::z)
                    )
                    .apply(Block::new);
            YamlDocument yamlDocument = sparrowYaml.load("""
            block:
              x: 1
              y: 2
              z: 3
            """);

            assertEquals(new Block(10, 2, 3), yamlDocument.get(blockCodec, Route.from("block")));
            UnexpectedNodeParsingException failure = assertInstanceOf(UnexpectedNodeParsingException.class, failures.get(0));
            assertEquals(Route.from("block", "x"), failure.path());
            assertEquals(Integer.class, failure.actualType());
            assertEquals(Integer.class, failure.targetType());
            assertSame(cause, failure.getCause());
        }

        @Test
        void should_LetOnFailHandleUnexpectedSequenceElementFailure() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            IllegalStateException cause = new IllegalStateException("element broke");
            List<RuntimeException> failures = new ArrayList<>();
            NodeSerializer<Integer> throwingInt = NodeSerializer.createInternal(
                    Integer.class,
                    node -> {
                        throw cause;
                    },
                    value -> value
            );
            NodeSerializer<Block> blockCodec = NodeSerializers.sequence(Block.class)
                    .group(
                            throwingInt.required(0).onFail(failure -> {
                                failures.add(failure);
                                return 10;
                            }).forGetter(Block::x),
                            NodeSerializers.INT.required(1).forGetter(Block::y),
                            NodeSerializers.INT.required(2).forGetter(Block::z)
                    )
                    .apply(Block::new);
            YamlDocument yamlDocument = sparrowYaml.load("""
            block:
              - 1
              - 2
              - 3
            """);

            assertEquals(new Block(10, 2, 3), yamlDocument.get(blockCodec, Route.from("block")));
            UnexpectedNodeParsingException failure = assertInstanceOf(UnexpectedNodeParsingException.class, failures.get(0));
            assertEquals(Route.from("block", 0), failure.path());
            assertEquals(Integer.class, failure.actualType());
            assertEquals(Integer.class, failure.targetType());
            assertSame(cause, failure.getCause());
        }

        @Test
        void should_TryAlternative_When_PrimaryThrowsUnexpectedRuntimeException() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<String> serializer = NodeSerializer.<String>createInternal(
                            String.class,
                            node -> {
                                throw new IllegalStateException("primary broke");
                            },
                            value -> value
                    )
                    .withAlternative(NodeSerializers.STRING, value -> "alternative:" + value);
            YamlDocument yamlDocument = sparrowYaml.load("""
            value: hello
            """);

            assertEquals("alternative:hello", yamlDocument.get(serializer, Route.from("value")));
        }

        @Test
        void should_AggregateUnexpectedFailures_When_AllAlternativesFail() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            IllegalStateException cause = new IllegalStateException("primary broke");
            NodeSerializer<String> serializer = NodeSerializer.<String>createInternal(
                            String.class,
                            node -> {
                                throw cause;
                            },
                            value -> value
                    )
                    .withAlternative(NodeSerializers.INT, String::valueOf);
            YamlDocument yamlDocument = sparrowYaml.load("""
            value: nope
            """);

            AlternativesNodeException failure = assertThrows(
                    AlternativesNodeException.class,
                    () -> yamlDocument.get(serializer, Route.from("value"))
            );
            assertEquals(2, failure.failures().size());
            assertEquals(2, failure.getSuppressed().length);
            UnexpectedNodeParsingException unexpected = assertInstanceOf(
                    UnexpectedNodeParsingException.class,
                    failure.failures().get(0).exception()
            );
            assertSame(cause, unexpected.getCause());
            assertEquals(Route.from("value"), failure.failures().get(0).path());
            assertEquals(String.class, failure.failures().get(0).targetType());
            assertInstanceOf(InvalidNodeException.class, failure.failures().get(1).exception());
        }

        @Test
        void should_WrapNoClassDefFoundError_When_DeserializerFails() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NoClassDefFoundError cause = new NoClassDefFoundError("missing/Dependency");
            NodeSerializer<String> throwingCodec = NodeSerializer.createInternal(
                    String.class,
                    node -> {
                        throw cause;
                    },
                    value -> value
            );
            YamlDocument yamlDocument = sparrowYaml.load("""
            value: hello
            """);

            UnexpectedNodeParsingException failure = assertThrows(
                    UnexpectedNodeParsingException.class,
                    () -> yamlDocument.get(throwingCodec, Route.from("value"))
            );
            assertEquals(Route.from("value"), failure.path());
            assertEquals(String.class, failure.actualType());
            assertEquals(String.class, failure.targetType());
            assertSame(cause, failure.getCause());
        }

        @Test
        void should_NotWrapFatalErrors_When_DeserializerFails() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            StackOverflowError stackOverflow = new StackOverflowError("fatal");
            ExceptionInInitializerError initializerFailure = new ExceptionInInitializerError(new OutOfMemoryError("fatal"));
            YamlDocument yamlDocument = sparrowYaml.load("""
            value: hello
            """);
            NodeSerializer<String> stackOverflowCodec = NodeSerializer.createInternal(
                    String.class,
                    node -> {
                        throw stackOverflow;
                    },
                    value -> value
            );
            NodeSerializer<String> initializerFailureCodec = NodeSerializer.createInternal(
                    String.class,
                    node -> {
                        throw initializerFailure;
                    },
                    value -> value
            );

            assertSame(stackOverflow, assertThrows(StackOverflowError.class, () -> yamlDocument.get(stackOverflowCodec, Route.from("value"))));
            assertSame(initializerFailure, assertThrows(ExceptionInInitializerError.class, () -> yamlDocument.get(initializerFailureCodec, Route.from("value"))));
        }

        @Test
        void should_ThrowInvalidException_When_NonNullSerializationReturnsNull() {
            NodeSerializer<NamedValue> nullingStringBacked = NodeSerializers.scalar(
                    NamedValue::new,
                    value -> null
            );
            InvalidNodeException stringBackedFailure = assertThrows(
                    InvalidNodeException.class,
                    () -> nullingStringBacked.serialize(new NamedValue("cat"))
            );
            assertNull(stringBackedFailure.path());
            assertEquals(NamedValue.class, stringBackedFailure.actualType());
            assertEquals(Object.class, stringBackedFailure.targetType());

            NodeSerializer<NamedValue> nullingXmap = NodeSerializers.STRING.xmap(
                    NamedValue::new,
                    value -> null
            );
            InvalidNodeException xmapFailure = assertThrows(
                    InvalidNodeException.class,
                    () -> nullingXmap.serialize(new NamedValue("dog"))
            );
            assertNull(xmapFailure.path());
            assertEquals(NamedValue.class, xmapFailure.actualType());
            assertEquals(Object.class, xmapFailure.targetType());

            assertNull(NodeSerializers.UUID.serialize(null));
        }

        @Test
        void should_DecodeScalarListAndMap_When_UsingObjectSerializer() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            scalar: value
            sequence:
              - alpha
              - 2
            mapping:
              name: cat
              nested:
                enabled: true
            """);

            assertEquals("value", yamlDocument.get(NodeSerializers.OBJECT, Route.from("scalar")));
            assertEquals(List.of("alpha", 2), yamlDocument.get(NodeSerializers.OBJECT, Route.from("sequence")));

            @SuppressWarnings("unchecked")
            Map<Object, Object> mapping = (Map<Object, Object>) yamlDocument.get(NodeSerializers.OBJECT, Route.from("mapping"));
            assertEquals("cat", mapping.get("name"));
            assertEquals(Map.of("enabled", true), mapping.get("nested"));
        }

        @Test
        void should_RejectCollectionNodes_When_UsingScalarSerializer() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            mapping:
              key: value
            sequence:
              - value
            """);

            InvalidNodeException mappingFailure = assertThrows(
                    InvalidNodeException.class,
                    () -> yamlDocument.get(NodeSerializers.SCALAR, Route.from("mapping"))
            );
            assertEquals(Route.from("mapping"), mappingFailure.path());
            assertEquals(SectionNode.class, mappingFailure.actualType());
            assertEquals(Object.class, mappingFailure.targetType());

            InvalidNodeException sequenceFailure = assertThrows(
                    InvalidNodeException.class,
                    () -> yamlDocument.get(NodeSerializers.SCALAR, Route.from("sequence"))
            );
            assertEquals(Route.from("sequence"), sequenceFailure.path());
            assertEquals(SequenceNode.class, sequenceFailure.actualType());
            assertEquals(Object.class, sequenceFailure.targetType());
        }

        @Test
        void should_ThrowMissingException_When_GetPathIsMissing_AndUseDefaultOnlyForMissingPath() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            value: 5
            """);

            MissingNodeException missing = assertThrows(
                    MissingNodeException.class,
                    () -> yamlDocument.get(NodeSerializers.INT, Route.from("missing"))
            );
            assertEquals("missing", missing.key());
            assertEquals(Route.from("missing"), missing.path());
            assertEquals(Integer.class, missing.targetType());

            MissingNodeException classMissing = assertThrows(
                    MissingNodeException.class,
                    () -> yamlDocument.get(Integer.class, Route.from("missing-class"))
            );
            assertEquals("missing-class", classMissing.key());
            assertEquals(Route.from("missing-class"), classMissing.path());
            assertEquals(Integer.class, classMissing.targetType());

            TypeRef<List<String>> listType = new TypeRef<>() {};
            MissingNodeException typeRefMissing = assertThrows(
                    MissingNodeException.class,
                    () -> yamlDocument.get(listType, Route.from("missing-list"))
            );
            assertEquals("missing-list", typeRefMissing.key());
            assertEquals(Route.from("missing-list"), typeRefMissing.path());
            assertEquals(List.class, typeRefMissing.targetType());

            assertEquals(42, yamlDocument.getOrDefault(42, NodeSerializers.INT, Route.from("missing")));
            assertEquals(5, yamlDocument.getOrDefault(42, NodeSerializers.INT, Route.from("value")));
        }

        @Test
        void should_KeepInvalidException_When_GetOrDefaultReadsInvalidExistingValue() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            value: nope
            """);

            InvalidNodeException failure = assertThrows(
                    InvalidNodeException.class,
                    () -> yamlDocument.getOrDefault(42, NodeSerializers.INT, Route.from("value"))
            );
            assertEquals(Route.from("value"), failure.path());
            assertEquals(String.class, failure.actualType());
            assertEquals(Integer.class, failure.targetType());
        }

        @Test
        @SuppressWarnings("unchecked")
        void should_DecodeRecursiveStructure_When_UsingNodeSerializersLazy() throws IOException {
            record Tree(String name, List<Tree> children) {}

            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<Tree>[] ref = new NodeSerializer[1];
            ref[0] = NodeSerializers.mapping(Tree.class)
                    .group(
                            NodeSerializers.STRING.required("name").forGetter(Tree::name),
                            NodeSerializers.lazy(() -> ref[0]).listOf().optional("children", List.of()).forGetter(Tree::children)
                    )
                    .apply(Tree::new);

            YamlDocument yamlDocument = sparrowYaml.load("""
            root:
              name: parent
              children:
                - name: child
            """);

            Tree root = yamlDocument.get(ref[0], Route.from("root"));

            assertEquals("parent", root.name());
            assertEquals(List.of(new Tree("child", List.of())), root.children());
        }

        @Test
        void should_DecodeScalarValueObject_When_UsingStringBacked() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<NamedValue> namedValueCodec = NodeSerializers.scalar(
                    value -> value.startsWith("name:") ? new NamedValue(value.substring(5)) : null,
                    value -> "name:" + value.value()
            );
            YamlDocument yamlDocument = sparrowYaml.load("""
            value: "name:cat"
            invalid: "cat"
            """);

            assertEquals(new NamedValue("cat"), yamlDocument.get(namedValueCodec, Route.from("value")));
            InvalidNodeException invalid = assertThrows(InvalidNodeException.class, () -> yamlDocument.get(namedValueCodec, Route.from("invalid")));
            assertEquals(Route.from("invalid"), invalid.path());
            assertEquals(String.class, invalid.actualType());
            assertEquals(Object.class, invalid.targetType());

            yamlDocument.setAndGet(namedValueCodec, new NamedValue("dog"), Route.from("encoded"));
            assertEquals("name:dog", yamlDocument.get(NodeSerializers.STRING, Route.from("encoded")));
        }

        @Test
        void should_DecodeMappingSequenceAndMultipleScalars_When_UsingPrimaryAlternatives() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<Block> blockCodec = blockPrimaryMappingCodec();
            YamlDocument yamlDocument = sparrowYaml.load("""
            map:
              x: 1
              y: 2
              z: 3
            list: [4, 5, 6]
            packed: 7008009
            csv: "10,11,12"
            """);

            assertEquals(new Block(1, 2, 3), yamlDocument.get(blockCodec, Route.from("map")));
            assertEquals(new Block(4, 5, 6), yamlDocument.get(blockCodec, Route.from("list")));
            assertEquals(new Block(7, 8, 9), yamlDocument.get(blockCodec, Route.from("packed")));
            assertEquals(new Block(10, 11, 12), yamlDocument.get(blockCodec, Route.from("csv")));
        }

        @Test
        void should_SerializePrimaryMapping_When_UsingMappingPrimaryAlternatives() {
            NodeSerializer<Block> blockCodec = blockPrimaryMappingCodec();

            Map<?, ?> encoded = assertInstanceOf(Map.class, blockCodec.serialize(new Block(1, 2, 3)));

            assertEquals(1, encoded.get("x"));
            assertEquals(2, encoded.get("y"));
            assertEquals(3, encoded.get("z"));
        }

        @Test
        void should_SerializePrimarySequence_When_UsingSequencePrimaryAlternatives() {
            NodeSerializer<Block> blockCodec = blockPrimarySequenceCodec();

            assertEquals(List.of(1, 2, 3), blockCodec.serialize(new Block(1, 2, 3)));
        }

        @Test
        void should_SerializePrimaryScalar_When_UsingScalarPrimaryAlternatives() {
            NodeSerializer<Block> blockCodec = blockPrimaryScalarCodec();

            assertEquals(1_002_003L, blockCodec.serialize(new Block(1, 2, 3)));
        }

        @Test
        void should_ReadLegacySequenceWithoutLegacyWriter_When_UsingConvertedAlternative() throws IOException {
            record Message(String value) {}

            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<Message> messageCodec = NodeSerializers.STRING
                    .xmap(Message.class, Message::new, Message::value)
                    .withAlternative(NodeSerializers.STRING.listOf(), lines -> new Message(String.join("\n", lines)));
            YamlDocument yamlDocument = sparrowYaml.load("""
            scalar: "hello"
            lines:
              - "hello"
              - "world"
            """);

            assertEquals(new Message("hello"), yamlDocument.get(messageCodec, Route.from("scalar")));
            assertEquals(new Message("hello\nworld"), yamlDocument.get(messageCodec, Route.from("lines")));
            assertEquals("hello\nworld", messageCodec.serialize(new Message("hello\nworld")));
        }

        @Test
        void should_ImportReadCandidates_When_AlternativeAlreadyHasAlternatives() throws IOException {
            record Message(String value) {}

            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<String> legacyText = NodeSerializers.STRING
                    .withAlternative(NodeSerializers.STRING.listOf(), lines -> String.join("\n", lines));
            NodeSerializer<Message> messageCodec = NodeSerializers.STRING
                    .xmap(Message.class, Message::new, Message::value)
                    .withAlternative(legacyText, Message::new);
            YamlDocument yamlDocument = sparrowYaml.load("""
            lines:
              - hello
              - world
            """);

            assertEquals(new Message("hello\nworld"), yamlDocument.get(messageCodec, Route.from("lines")));
            assertEquals("hello\nworld", messageCodec.serialize(new Message("hello\nworld")));
        }

        @Test
        void should_AggregateCandidateFailures_When_AlternativesCandidatesFail() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<Block> blockCodec = blockPrimaryMappingCodec();
            YamlDocument yamlDocument = sparrowYaml.load("""
            invalid-scalar: nope
            """);

            AlternativesNodeException scalarFailure = assertThrows(
                    AlternativesNodeException.class,
                    () -> yamlDocument.get(blockCodec, Route.from("invalid-scalar"))
            );
            assertEquals(Route.from("invalid-scalar"), scalarFailure.path());
            assertEquals(String.class, scalarFailure.actualType());
            assertEquals(Block.class, scalarFailure.targetType());
            assertEquals(4, scalarFailure.failures().size());
            assertEquals(4, scalarFailure.getSuppressed().length);
            assertInstanceOf(InvalidNodeException.class, scalarFailure.failures().get(0).exception());
            assertSame(scalarFailure.failures().get(0).exception(), scalarFailure.getSuppressed()[0]);
            assertEquals(Route.from("invalid-scalar"), scalarFailure.failures().get(0).path());
            assertEquals(Block.class, scalarFailure.failures().get(0).targetType());
            assertInstanceOf(InvalidNodeException.class, scalarFailure.failures().get(1).exception());
            assertSame(scalarFailure.failures().get(1).exception(), scalarFailure.getSuppressed()[1]);
            assertEquals(Route.from("invalid-scalar"), scalarFailure.failures().get(1).path());
            assertEquals(Block.class, scalarFailure.failures().get(1).targetType());
            assertInstanceOf(InvalidNodeException.class, scalarFailure.failures().get(2).exception());
            assertSame(scalarFailure.failures().get(2).exception(), scalarFailure.getSuppressed()[2]);
            assertEquals(Route.from("invalid-scalar"), scalarFailure.failures().get(2).path());
            assertEquals(Long.class, scalarFailure.failures().get(2).targetType());
            assertInstanceOf(UnexpectedNodeParsingException.class, scalarFailure.failures().get(3).exception());
            assertSame(scalarFailure.failures().get(3).exception(), scalarFailure.getSuppressed()[3]);
            assertEquals(Route.from("invalid-scalar"), scalarFailure.failures().get(3).path());
            assertEquals(Block.class, scalarFailure.failures().get(3).targetType());
        }

        @Test
        void should_AggregateCandidateFailures_When_PrimaryAndAlternativeFail() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<Block> mappingWithScalarAlternative = NodeSerializers.mapping(Block.class)
                    .group(
                            NodeSerializers.INT.required("x").forGetter(Block::x),
                            NodeSerializers.INT.required("y").forGetter(Block::y),
                            NodeSerializers.INT.required("z").forGetter(Block::z)
                    )
                    .apply(Block::new)
                    .withAlternative(NodeSerializers.LONG, Block::fromPackedLong);
            YamlDocument yamlDocument = sparrowYaml.load("""
            block:
              x: 1
              z: 3
            """);

            AlternativesNodeException failure = assertThrows(
                    AlternativesNodeException.class,
                    () -> yamlDocument.get(mappingWithScalarAlternative, Route.from("block"))
            );
            assertEquals(2, failure.failures().size());
            assertInstanceOf(MissingNodeException.class, failure.failures().get(0).exception());
            assertEquals("y", failure.failures().get(0).missingKey());
            assertEquals(Route.from("block", "y"), failure.failures().get(0).path());
            assertEquals(Integer.class, failure.failures().get(0).targetType());
            assertInstanceOf(InvalidNodeException.class, failure.failures().get(1).exception());
            assertEquals(Route.from("block"), failure.failures().get(1).path());
            assertEquals(Long.class, failure.failures().get(1).targetType());
        }

        @Test
        void should_TryAllCandidates_When_NodeKindDiffers() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<Block> mappingOnly = NodeSerializers.mapping(Block.class)
                    .group(
                            NodeSerializers.INT.required("x").forGetter(Block::x),
                            NodeSerializers.INT.required("y").forGetter(Block::y),
                            NodeSerializers.INT.required("z").forGetter(Block::z)
                    )
                    .apply(Block::new)
                    .withAlternative(NodeSerializers.LONG, Block::fromPackedLong);
            YamlDocument yamlDocument = sparrowYaml.load("""
            block: [1, 2, 3]
            """);

            AlternativesNodeException failure = assertThrows(
                    AlternativesNodeException.class,
                    () -> yamlDocument.get(mappingOnly, Route.from("block"))
            );
            assertEquals(Route.from("block"), failure.path());
            assertEquals(SequenceNode.class, failure.actualType());
            assertEquals(Block.class, failure.targetType());
            assertEquals(2, failure.failures().size());
            assertEquals(2, failure.getSuppressed().length);
            assertInstanceOf(InvalidNodeException.class, failure.failures().get(0).exception());
            assertInstanceOf(InvalidNodeException.class, failure.failures().get(1).exception());
        }

        @Test
        void should_TryAlternativesInOrder_When_UsingUnifiedAlternativeApi() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<String> serializer = NodeSerializers.STRING
                    .withAlternative(NodeSerializers.STRING.listOf(), values -> String.join(",", values));
            YamlDocument yamlDocument = sparrowYaml.load("""
            scalar: hello
            list:
              - hello
              - world
            """);

            assertEquals("hello", yamlDocument.get(serializer, Route.from("scalar")));
            assertEquals("hello,world", yamlDocument.get(serializer, Route.from("list")));
            assertEquals("hello,world", serializer.serialize("hello,world"));
        }

        @Test
        void should_PreferPrimary_When_PrimaryAndAlternativeCanBothDecode() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<String> serializer = NodeSerializers.STRING
                    .xmap(String.class, value -> "primary:" + value, value -> value)
                    .withAlternative(NodeSerializers.STRING, value -> "alternative:" + value);
            YamlDocument yamlDocument = sparrowYaml.load("""
            value: hello
            """);

            assertEquals("primary:hello", yamlDocument.get(serializer, Route.from("value")));
        }

        @Test
        void should_FailFast_When_OptionalDefaultIsNull() {
            assertThrows(NullPointerException.class, () -> NodeSerializers.INT.optional("y", null));
            assertThrows(NullPointerException.class, () -> NodeSerializers.INT.optional(1, null));
        }

        @Test
        void should_ThrowInvalidException_When_BuiltInSerializerCannotParseValue() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.load("""
            number: nope
            bool: maybe
            uuid: definitely-not-a-uuid
            section:
              nested: true
            """);

            InvalidNodeException numberFailure = assertThrows(
                    InvalidNodeException.class,
                    () -> yamlDocument.get(NodeSerializers.INT, Route.from("number"))
            );
            assertEquals(Route.from("number"), numberFailure.path());
            assertEquals(String.class, numberFailure.actualType());
            assertEquals(Integer.class, numberFailure.targetType());

            InvalidNodeException typeFailure = assertThrows(
                    InvalidNodeException.class,
                    () -> yamlDocument.get(NodeSerializers.STRING, Route.from("section"))
            );
            assertEquals(Route.from("section"), typeFailure.path());
            assertEquals(SectionNode.class, typeFailure.actualType());
            assertEquals(String.class, typeFailure.targetType());

            InvalidNodeException boolFailure = assertThrows(
                    InvalidNodeException.class,
                    () -> yamlDocument.get(NodeSerializers.BOOLEAN, Route.from("bool"))
            );
            assertEquals(Route.from("bool"), boolFailure.path());
            assertEquals(String.class, boolFailure.actualType());
            assertEquals(Boolean.class, boolFailure.targetType());

            InvalidNodeException uuidFailure = assertThrows(
                    InvalidNodeException.class,
                    () -> yamlDocument.get(NodeSerializers.UUID, Route.from("uuid"))
            );
            assertEquals(Route.from("uuid"), uuidFailure.path());
            assertEquals(String.class, uuidFailure.actualType());
            assertEquals(UUID.class, uuidFailure.targetType());
        }

        @Test
        void should_ThrowInvalidException_When_EnumSerializerCannotParseValue() throws IOException {
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            NodeSerializer<Mode> modeCodec = NodeSerializers.enumCodec(Mode.class);
            YamlDocument yamlDocument = sparrowYaml.load("""
            mode: medium
            section:
              nested: true
            """);

            InvalidNodeException valueFailure = assertThrows(
                    InvalidNodeException.class,
                    () -> yamlDocument.get(modeCodec, Route.from("mode"))
            );
            assertEquals(Route.from("mode"), valueFailure.path());
            assertEquals(String.class, valueFailure.actualType());
            assertEquals(Mode.class, valueFailure.targetType());
            assertEquals("Invalid YAML value at path \"mode\": actual String, expected Mode", valueFailure.getMessage());

            InvalidNodeException typeFailure = assertThrows(
                    InvalidNodeException.class,
                    () -> yamlDocument.get(modeCodec, Route.from("section"))
            );
            assertEquals(Route.from("section"), typeFailure.path());
            assertEquals(SectionNode.class, typeFailure.actualType());
            assertEquals(Mode.class, typeFailure.targetType());
            assertEquals("Invalid YAML value at path \"section\": actual Map, expected Mode", typeFailure.getMessage());
        }

        @Test
        void should_DecodeBasicTypes_When_UsingBuiltInCodecs() throws Throwable {
            // 1. 准备阶段 (Arrange)
            SparrowYaml sparrowYaml = SparrowYaml.builder().build();
            YamlDocument yamlDocument = sparrowYaml.loadFromResource("full-test.yml");

            // 2. 执行阶段 (Act) & 3. 断言阶段 (Assert)
            Integer integer1 = yamlDocument.get(NodeSerializers.INT, Route.from("test", "int"));
            assertEquals(1314, integer1);

            String string1 = yamlDocument.get(NodeSerializers.STRING, Route.from("test", "string-1"));
            assertEquals("test", string1);

            String quoted = yamlDocument.get(NodeSerializers.STRING, Route.from("test", "quoted"));
            assertEquals("So does this quoted scalar.\n", quoted);

            List<String> stringList = yamlDocument.get(NodeSerializers.STRING.listOf(), Route.from("test", "string_list"));
            assertEquals(List.of("qwq", "awa", "fwf"), stringList);
        }
    }
}

final class PluginResourceAnchor {
}
