rootProject.name = "sparrow-yaml"
include("common")
include("minecraft")
